using System.ComponentModel;
using Microsoft.Win32.SafeHandles;

/// <summary>Opt-in benchmark counters, restricted to this test process and its descendants.</summary>
internal sealed class MultistreamProcessMetrics : IDisposable
{
    private readonly Dictionary<int, Process> processes = [];
    private readonly IntPtr gpuQuery;
    private readonly IntPtr gpuCounter;
    internal string? GpuError { get; private set; }

    internal MultistreamProcessMetrics()
    {
        var status = PdhOpenQueryW(null, UIntPtr.Zero, out gpuQuery);
        if (status == 0) status = PdhAddEnglishCounterW(gpuQuery, @"\GPU Engine(*)\Utilization Percentage", UIntPtr.Zero, out gpuCounter);
        if (status == 0) status = PdhCollectQueryData(gpuQuery);
        if (status != 0) GpuError = $"PDH initialization: 0x{status:x8}";
    }

    internal IReadOnlyList<ProcessCounterSample> Sample()
    {
        using var snapshot = CreateToolhelp32Snapshot(2, 0);
        if (snapshot.IsInvalid) throw new Win32Exception(Marshal.GetLastPInvokeError());
        var entry = new ProcessEntry { Size = (uint)Marshal.SizeOf<ProcessEntry>() };
        var parents = new Dictionary<int, int>();
        if (Process32FirstW(snapshot, ref entry))
        {
            do { parents[entry.ProcessId] = entry.ParentProcessId; } while (Process32NextW(snapshot, ref entry));
        }
        var ids = new HashSet<int> { Environment.ProcessId };
        bool changed;
        do
        {
            changed = false;
            foreach (var (pid, parent) in parents)
                if (ids.Contains(parent)) changed |= ids.Add(pid);
        } while (changed);
        foreach (var id in ids)
        {
            if (processes.ContainsKey(id)) continue;
            try
            {
                var process = Process.GetProcessById(id);
                _ = process.SafeHandle;
                processes.Add(id, process);
            }
            catch (ArgumentException) { }
        }
        var samples = new List<ProcessCounterSample>();
        foreach (var process in processes.Values)
        {
            process.Refresh();
            if (process.HasExited) continue;
            if (!GetProcessIoCounters(process.SafeHandle, out var io)) throw new Win32Exception(Marshal.GetLastPInvokeError());
            samples.Add(new ProcessCounterSample(process.Id, process.ProcessName, process.TotalProcessorTime.TotalSeconds,
                process.PrivateMemorySize64, process.WorkingSet64, io.ReadTransferCount, io.WriteTransferCount));
        }
        return samples;
    }

    internal IReadOnlyDictionary<string, double> SampleGpu(IEnumerable<int> processIds)
    {
        var result = new Dictionary<string, double>(StringComparer.Ordinal);
        if (GpuError is not null) return result;
        var status = PdhCollectQueryData(gpuQuery);
        uint bytes = 0, count = 0;
        const uint format = 0x200 | 0x8000; // DOUBLE | NOCAP100; sum only this tree's instances by engine type.
        if (status == 0) status = PdhGetFormattedCounterArrayW(gpuCounter, format, ref bytes, ref count, IntPtr.Zero);
        if (status != 0x800007D2) { GpuError = $"PDH size: 0x{status:x8}"; return result; }
        var buffer = Marshal.AllocHGlobal(checked((int)bytes));
        try
        {
            status = PdhGetFormattedCounterArrayW(gpuCounter, format, ref bytes, ref count, buffer);
            if (status != 0) { GpuError = $"PDH data: 0x{status:x8}"; return result; }
            var ids = processIds.ToHashSet();
            var itemSize = Marshal.SizeOf<GpuCounterItem>();
            for (var index = 0; index < count; index++)
            {
                var item = Marshal.PtrToStructure<GpuCounterItem>(buffer + index * itemSize);
                if (item.Status > 1 || !double.IsFinite(item.Value)) continue;
                var name = Marshal.PtrToStringUni(item.Name)!;
                var pieces = name.Split('_');
                if (pieces.Length < 3 || pieces[0] != "pid" || !int.TryParse(pieces[1], out var pid) || !ids.Contains(pid)) continue;
                var engine = name.IndexOf("engtype_", StringComparison.Ordinal);
                var key = engine >= 0 ? name[(engine + 8)..] : "unknown";
                result[key] = result.GetValueOrDefault(key) + item.Value;
            }
        }
        finally { Marshal.FreeHGlobal(buffer); }
        return result;
    }

    internal async Task AssertChildrenExitedAsync()
    {
        foreach (var process in processes.Values.Where(process => process.Id != Environment.ProcessId))
            await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(8));
    }

    public void Dispose()
    {
        if (gpuQuery != IntPtr.Zero) _ = PdhCloseQuery(gpuQuery);
        foreach (var process in processes.Values) process.Dispose();
    }

    internal sealed record ProcessCounterSample(int Pid, string Name, double CpuSeconds, long PrivateBytes, long WorkingSetBytes,
        ulong ReadBytes, ulong WriteBytes);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct ProcessEntry
    {
        public uint Size, Usage;
        public int ProcessId;
        public UIntPtr DefaultHeapId;
        public uint ModuleId, Threads;
        public int ParentProcessId, Priority;
        public uint Flags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string Executable;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IoCounters
    {
        public ulong ReadOperationCount, WriteOperationCount, OtherOperationCount, ReadTransferCount, WriteTransferCount, OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct GpuCounterItem
    {
        public IntPtr Name;
        public uint Status;
        public double Value;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern SafeFileHandle CreateToolhelp32Snapshot(uint flags, uint processId);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool Process32FirstW(SafeFileHandle snapshot, ref ProcessEntry entry);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool Process32NextW(SafeFileHandle snapshot, ref ProcessEntry entry);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetProcessIoCounters(SafeProcessHandle process, out IoCounters counters);
    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhOpenQueryW(string? source, UIntPtr userData, out IntPtr query);
    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhAddEnglishCounterW(IntPtr query, string path, UIntPtr userData, out IntPtr counter);
    [DllImport("pdh.dll")]
    private static extern uint PdhCollectQueryData(IntPtr query);
    [DllImport("pdh.dll", CharSet = CharSet.Unicode)]
    private static extern uint PdhGetFormattedCounterArrayW(IntPtr counter, uint format, ref uint bufferSize, ref uint itemCount, IntPtr items);
    [DllImport("pdh.dll")]
    private static extern uint PdhCloseQuery(IntPtr query);
}
