using System.Buffers.Binary;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shell;
using System.Windows.Threading;
using Microsoft.Win32;
using StreamlinkVlcStudio.App.Wpf.Chat;
using StreamlinkVlcStudio.App.Wpf.Controls;
using StreamlinkVlcStudio.App.Wpf.Notifications;
using StreamlinkVlcStudio.App.Wpf.ViewModels;
using StreamlinkVlcStudio.Core.Logging;
using StreamlinkVlcStudio.Core.Models;
using StreamlinkVlcStudio.Core.Services;
using StreamlinkVlcStudio.Core.Settings;
using StreamlinkVlcStudio.Infrastructure.Chat;
using StreamlinkVlcStudio.Infrastructure.Logging;
using StreamlinkVlcStudio.Infrastructure.Processes;
using StreamlinkVlcStudio.Infrastructure.Replay;
using StreamlinkVlcStudio.Infrastructure.Settings;
using StreamlinkVlcStudio.Infrastructure.Streamlink;
using StreamlinkVlcStudio.Infrastructure.Twitch;
using StreamlinkVlcStudio.Infrastructure.Updates;
using StreamlinkVlcStudio.Infrastructure.Vlc;
using StreamlinkVlcStudio.Infrastructure.Viewers;
using StreamlinkVlcStudio.Infrastructure.Vod;
using StreamlinkVlcStudio.App.Wpf.Themes;
using StreamlinkVlcStudio.App.Wpf.Twitch;
using static StreamlinkVlcStudio.App.Wpf.WindowInteropHelpers;

namespace StreamlinkVlcStudio.App.Wpf;

public partial class MainWindow : Window
{
    private readonly DockedChatScrollController dockedChatController;
    private readonly PictureInPictureController pictureInPicture;
    private readonly WindowModeController windowMode;
    private TwitchChannelPointsController? twitchChannelPoints;
    internal enum FullscreenMode
    {
        None,
        StreamOnly,
        MultiView,
        Theatre
    }

    private const int WmLeftButtonUp = 0x0202;
    private const int WmLeftButtonDoubleClick = 0x0203;
    private const int WmMouseMove = 0x0200;
    private const int WmRightButtonUp = 0x0205;
    private const int WmGetMinMaxInfo = 0x0024;
    private const int WmAppTrayIcon = 0x8001;
    private const int WmAppCommand = 0x0319;
    private const int SmCxDrag = 68;
    private const int SmCyDrag = 69;
    private const int VkLeftButton = 0x01;
    private const int VkControl = 0x11;
    private const int VkLeftControl = 0xA2;
    private const int VkRightControl = 0xA3;
    private const int TrayCommandOpen = 1001;
    private const int TrayCommandExit = 1002;
    private const uint TrayIconId = 1;
    private const int NimAdd = 0x00000000;
    private const int NimDelete = 0x00000002;
    private const uint NifMessage = 0x00000001;
    private const uint NifIcon = 0x00000002;
    private const uint NifTip = 0x00000004;
    private const uint MfString = 0x00000000;
    private const uint MfSeparator = 0x00000800;
    private const uint TpmRightButton = 0x00000002;
    private const uint TpmReturnCommand = 0x00000100;
    private const int IdiApplication = 32512;
    private const double ChatBottomFollowTolerance = 2;
    private static readonly HotkeySettings DefaultHotkeys = new();
    private const double ChatPixelsPerWheelNotch = 54;
    private const double TabPixelsPerWheelNotch = 96;
    private const double TitleBarChromeCaptionHeight = 36;
    private const double BrowseCategoryLoadMoreBottomThreshold = 120;
    private const double TabDetachOuterMargin = 10;
    private const double DetachedWindowDefaultWidth = 520;
    private const double DetachedWindowTitleBarHeight = 34;
    private const double DetachedWindowCascadeOffset = 36;
    private const double DetachedWindowCascadeDuplicateTolerance = 24;
    private const int DetachedWindowCascadeAttempts = 12;
    private static readonly Thickness WindowChromeResizeBorderThickness = new(6);
    private const int DefaultOverlayChatX = 24;
    private const int DefaultOverlayChatY = 24;
    private const int DefaultOverlayChatHeight = 292;
    private const double OverlayChatHitInsetPixels = 3;
    private const int OverlayMessagePadding = 8;
    private const int OverlayChatInputHeight = 30;
    private const int OverlayChatInputGap = 6;
    private const int OverlayButtonMargin = 6;
    private const int OverlayHideButtonWidth = 58;
    private const int OverlayHideButtonHeight = 22;
    private const int VideoReorderPollIntervalMilliseconds = 16;
    private static readonly TimeSpan HomeAutoScrollInterval = TimeSpan.FromMilliseconds(16);
    private static readonly TimeSpan ShutdownTimeout = TimeSpan.FromSeconds(8);
    private static readonly int WmTaskbarCreated = RegisterWindowMessage("TaskbarCreated");
    private static ITaskbarFullscreenController taskbarFullscreenController = WindowsTaskbarFullscreenController.Instance;
    private readonly Dictionary<StreamTabViewModel, VideoSurface> videoSurfaces = [];
    private Dictionary<StreamTabViewModel, DetachedVideoWindow> detachedWindows { get => pictureInPicture.detachedWindows; }
    private readonly IWindowHitTester windowHitTester;
    private MainViewModel? viewModel;
    private ISettingsService? settingsService;
    private IAppLogger? appLogger;
    private TwitchMutedVodPlaybackGateway? twitchMutedVodPlaybackGateway;
    private ToastLiveNotificationService? liveNotificationService;
    private LowLevelMouseHookPump? mouseHookPump;
    private DispatcherTimer? videoReorderPollTimer;
    private DispatcherTimer? homeAutoScrollTimer;
    private IntPtr windowHandle;
    private ScrollViewer? homeAutoScrollViewer;
    private bool exitRequested { get => windowMode.exitRequested; set => windowMode.exitRequested = value; }
    private bool fullscreen { get => windowMode.fullscreen; set => windowMode.fullscreen = value; }
    private bool closeConfirmed;
    private bool shutdownStarted;
    private readonly DoubleClickTracker videoDoubleClickTracker = new();
    private FrameworkElement? tabDetachDragSource;
    private StreamTabViewModel? tabDetachDragTab;
    private StreamTabViewModel? tabDetachDragMergeTarget;
    private StreamTabViewModel[] tabDetachDragTabs = [];
    private StreamTabViewModel? videoReorderDragTab;
    private Func<bool> isLeftMouseButtonPressed = IsLeftMouseButtonPressed;
    private Func<bool> isControlModifierPressed = IsControlModifierPressed;
    private Func<NativePoint?> getVideoReorderCursorScreenPoint = GetCursorScreenPoint;
    private Point tabDetachDragStartPoint;
    private NativePoint tabDetachDragStartScreenPoint;
    private NativePoint videoReorderDragStartScreenPoint;
    private Point homeAutoScrollAnchorPoint;
    private Point homeAutoScrollCursorPoint;
    private bool videoReorderDragStarted;
    private bool videoReorderDragReordered;
    private bool videoReorderPollLeftButtonWasPressed;
    private bool tabStripReorderDragReordered;
    private bool tabDetachDragStartedWithControlModifier;
    private volatile bool hasActiveLowLevelMouseMoveRoute;
    private readonly bool setupRequested;
    private long homeAutoScrollLastTickTimestamp;
    private Cursor? homeAutoScrollPreviousCursor;
    private FullscreenMode fullscreenMode { get => windowMode.fullscreenMode; set => windowMode.fullscreenMode = value; }

    public MainWindow(bool setupRequested = false)
        : this(setupRequested, NativeWindowHitTester.Instance)
    {
    }

    internal MainWindow(bool setupRequested, IWindowHitTester windowHitTester)
    {
        this.setupRequested = setupRequested;
        this.windowHitTester = windowHitTester ?? throw new ArgumentNullException(nameof(windowHitTester));
        dockedChatController = new DockedChatScrollController(this);
        pictureInPicture = new PictureInPictureController(this);
        windowMode = new WindowModeController(this);
        InitializeComponent();
        DataContextChanged += (_, e) => SetLibraryScrollViewModel(e.NewValue as MainViewModel);
        Closed += (_, _) => SetLibraryScrollViewModel(null);
        DataContextChanged += (_, e) => SetStudioNavigationViewModel(e.NewValue as MainViewModel);
        Closed += (_, _) => SetStudioNavigationViewModel(null);
        PlaybackHost.SizeChanged += (_, _) => UpdateResponsiveLayout();
        ApplyWindowChromeHitTestState();
        dockedChatController.Attach();
        SourceInitialized += MainWindowSourceInitialized;
        Loaded += MainWindowLoaded;
        Activated += MainWindowActivated;
        StateChanged += MainWindowStateChanged;
        PreviewMouseDown += MainWindowPreviewMouseDown;
        PreviewMouseUp += MainWindowPreviewMouseUp;
        PreviewGotKeyboardFocus += MainWindowPreviewGotKeyboardFocus;
        PreviewMouseMove += MainWindowPreviewMouseMove;
        PreviewMouseLeftButtonUp += MainWindowPreviewMouseLeftButtonUp;
        PreviewKeyDown += MainWindowPreviewKeyDown;
        Closing += MainWindowClosing;
        Closed += MainWindowClosed;
    }

    internal static ITaskbarFullscreenController TaskbarFullscreenController
    {
        get => taskbarFullscreenController;
        set => taskbarFullscreenController = value ?? WindowsTaskbarFullscreenController.Instance;
    }

    private void MainWindowSourceInitialized(object? sender, EventArgs e)
    {
        windowHandle = new WindowInteropHelper(this).Handle;
        HwndSource.FromHwnd(windowHandle)?.AddHook(WindowMessageHook);
        InitializeTrayIcon();
        InstallMouseWheelHook();
        StartVideoReorderPolling();
        if (ShouldMarkTaskbarFullscreen())
        {
            MarkTaskbarFullscreen();
        }
    }

    private IntPtr WindowMessageHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == WmAppCommand && TryExecuteNativeMouseAppCommand(wParam, lParam))
        {
            handled = true;
            return new IntPtr(1);
        }

        if (msg == WmGetMinMaxInfo)
        {
            ApplyMonitorMaxInfo(hwnd, lParam, useFullMonitor: fullscreen && fullscreenMode != FullscreenMode.Theatre);
            if (lParam != IntPtr.Zero)
            {
                // The layout has no artificial minimum. Keep native tracking in sync
                // instead of letting Windows and WPF disagree about the client size.
                var limits = Marshal.PtrToStructure<MinMaxInfo>(lParam);
                limits.MinTrackSize = new WindowPoint { X = 1, Y = 1 };
                Marshal.StructureToPtr(limits, lParam, false);
            }
            handled = true;
        }
        else if (msg == WmTaskbarCreated && ShouldMarkTaskbarFullscreen())
        {
            MarkTaskbarFullscreen(force: true);
        }
        else if (msg == WmAppTrayIcon)
        {
            HandleTrayIconMessage(lParam);
            handled = true;
        }
        else if (msg == WmMouseMove &&
            (tabDetachDragTab is not null || videoReorderDragTab is not null))
        {
            var screenPoint = GetCursorScreenPoint() ?? ClientMessagePointToNativeScreenPoint(lParam);
            var handledDrag = TryContinueVideoReorderDrag(screenPoint);
            if (tabDetachDragTab is not null &&
                TryContinueTabDetachDrag(screenPoint, continueDrag: true))
            {
                handledDrag = true;
            }

            handled = handledDrag;
        }
        else if (msg == WmLeftButtonUp &&
            (tabDetachDragTab is not null || videoReorderDragTab is not null))
        {
            var screenPoint = GetCursorScreenPoint() ?? ClientMessagePointToNativeScreenPoint(lParam);
            var handledDrag = TryCompleteVideoReorderDrag(screenPoint);
            if (TryCompleteTabDetachDrag(screenPoint))
            {
                handledDrag = true;
            }

            ClearVideoReorderDrag();
            ClearTabDetachDrag();
            handled = handledDrag;
        }

        return IntPtr.Zero;
    }

    private void MainWindowStateChanged(object? sender, EventArgs e)
    {
        ApplyWindowChromeHitTestState();
        UpdateMaximizeRestoreButton();
        if (ShouldMarkTaskbarFullscreen())
        {
            MarkTaskbarFullscreen();
        }
    }

    private void MainWindowActivated(object? sender, EventArgs e)
    {
        viewModel?.ActivateMainWindowAudio();
        if (ShouldMarkTaskbarFullscreen())
        {
            MarkTaskbarFullscreen();
        }
    }

    private void MainWindowPreviewKeyDown(object sender, KeyEventArgs e)
    {
        var input = new HotkeyGesture(HotkeyGesture.GetEventKey(e), Keyboard.Modifiers);
        if (TryExecuteHotkey(input, Keyboard.FocusedElement, e.IsRepeat))
        {
            e.Handled = true;
        }
    }

    internal bool TryExecuteHotkey(HotkeyGesture input, IInputElement? focusedElement, bool isRepeat = false)
    {
        if (focusedElement is HotkeyRecorderButton { IsCapturingInput: true })
        {
            return false;
        }

        if (TryNavigateHomeSearch(input, focusedElement)) return true;

        if (input is { Key: Key.Escape, Modifiers: ModifierKeys.None, MouseButton: null } &&
            viewModel?.IsStreamSearchPanelVisible == true)
        {
            HomeStreamSearchTextBox.Focus();
            viewModel.DismissStreamSearchDropdown();
            return true;
        }

        var hotkeys = viewModel?.Settings.Hotkeys ?? DefaultHotkeys;
        var dismissShortcutPressed = HotkeyBindingPolicy.Matches(
            hotkeys, AppHotkeyAction.DismissFullscreenOrAutoScroll, input);
        var dismissShortcutSuppressed = HotkeyBindingPolicy.ShouldSuppressForTextInput(
            hotkeys, AppHotkeyAction.DismissFullscreenOrAutoScroll, focusedElement);
        if (homeAutoScrollViewer is not null && dismissShortcutPressed && !dismissShortcutSuppressed)
        {
            ClearHomeAutoScroll();
            return true;
        }

        if (fullscreen && dismissShortcutPressed && !dismissShortcutSuppressed)
        {
            ExitFullscreenMode();
            return true;
        }

        if (HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.ToggleReplaySeekBar, input) &&
            !HotkeyBindingPolicy.ShouldSuppressForTextInput(hotkeys, AppHotkeyAction.ToggleReplaySeekBar, focusedElement))
        {
            TryExecuteReplaySeekBarShortcut(viewModel);
            return true;
        }

        var tabAction = HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.PreviousTab, input)
            ? AppHotkeyAction.PreviousTab
            : HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.NextTab, input)
                ? AppHotkeyAction.NextTab
                : (AppHotkeyAction?)null;
        if (tabAction is not null &&
            !HotkeyBindingPolicy.ShouldSuppressForTextInput(hotkeys, tabAction.Value, focusedElement) &&
            HotkeyBindingPolicy.CanNavigateTabs(
                fullscreen, fullscreenMode != FullscreenMode.None, viewModel?.IsSettingsOpen == true))
        {
            var direction = tabAction == AppHotkeyAction.PreviousTab ? -1 : 1;
            if (viewModel?.SelectAdjacentTab(direction) == true)
            {
                if (fullscreen)
                {
                    ApplyFullscreenSelectedTabState();
                }

                return true;
            }

            // Preserve older custom tab bindings that overlap a newly added default.
            return false;
        }

        return TryExecutePlaybackHotkey(input, focusedElement, isRepeat) ||
            TryExecuteGoBackHotkey(input, focusedElement, isRepeat);
    }

    internal bool TryExecuteGoBackHotkey(
        HotkeyGesture input,
        IInputElement? focusedElement,
        bool isRepeat = false)
    {
        if (viewModel is null ||
            focusedElement is HotkeyRecorderButton { IsCapturingInput: true } ||
            !HotkeyBindingPolicy.Matches(viewModel.Settings.Hotkeys, AppHotkeyAction.GoBack, input) ||
            HotkeyBindingPolicy.ShouldSuppressForTextInput(viewModel.Settings.Hotkeys, AppHotkeyAction.GoBack, focusedElement) ||
            !viewModel.GoBackCommand.CanExecute(null))
        {
            return false;
        }

        if (!isRepeat)
        {
            if (fullscreen)
            {
                ExitFullscreenMode();
            }

            viewModel.GoBackCommand.Execute(null);
        }

        return true;
    }

    internal bool TryExecutePlaybackHotkey(
        Key key,
        ModifierKeys modifiers,
        IInputElement? focusedElement,
        bool isRepeat = false)
        => TryExecutePlaybackHotkey(new HotkeyGesture(key, modifiers), focusedElement, isRepeat);

    private bool TryExecutePlaybackHotkey(HotkeyGesture input, IInputElement? focusedElement, bool isRepeat)
    {
        if (viewModel is null || viewModel.IsSettingsOpen ||
            focusedElement is HotkeyRecorderButton { IsCapturingInput: true })
        {
            return false;
        }

        var hotkeys = viewModel.Settings.Hotkeys;
        if (HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.ToggleMultiStream, input) &&
            !HotkeyBindingPolicy.ShouldSuppressForTextInput(hotkeys, AppHotkeyAction.ToggleMultiStream, focusedElement))
        {
            if (!isRepeat)
            {
                viewModel.ToggleMultiStreamCommand.Execute(null);
            }

            return true;
        }

        if (viewModel.IsHomeSelected || viewModel.SelectedTab is not { } tab)
        {
            return false;
        }

        var volumeAction = HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.VolumeUp, input)
            ? AppHotkeyAction.VolumeUp
            : HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.VolumeDown, input)
                ? AppHotkeyAction.VolumeDown
                : (AppHotkeyAction?)null;
        if (volumeAction is null)
        {
            // Keep an older custom Back binding if it overlaps a new skip default.
            if (HotkeyBindingPolicy.Matches(hotkeys, AppHotkeyAction.GoBack, input)) return false;
            return ReplaySkipHotkey.TryExecute(tab, hotkeys, input, focusedElement, isRepeat);
        }

        if (HotkeyBindingPolicy.ShouldSuppressForTextInput(hotkeys, volumeAction.Value, focusedElement))
        {
            return false;
        }

        var direction = volumeAction == AppHotkeyAction.VolumeUp ? 1 : -1;
        tab.Volume += direction * VolumeOverlay.WheelStep;
        VolumeOsd.Show(ResolveVolumeOsdTarget(tab), tab.Volume, tab.IsMuted);
        return true;
    }

    internal static bool TryExecuteReplaySeekBarShortcut(MainViewModel? viewModel)
    {
        var command = viewModel?.ToggleReplaySeekBarCommand;
        if (command?.CanExecute(null) != true)
        {
            return false;
        }

        command.Execute(null);
        return true;
    }

    private void HotkeyRecorder_GestureChanging(object? sender, HotkeyGestureChangingEventArgs e)
    {
        if (sender is not HotkeyRecorderButton { Tag: string actionName } recorder ||
            !Enum.TryParse(actionName, ignoreCase: false, out AppHotkeyAction action) ||
            !Enum.IsDefined(action))
        {
            e.Cancel = true;
            return;
        }

        var currentViewModel = viewModel ?? recorder.DataContext as MainViewModel;
        if (currentViewModel is null)
        {
            e.Cancel = true;
            return;
        }

        _ = HotkeyBindingPolicy.SwapConflictingBinding(
            currentViewModel.Settings.Hotkeys,
            action,
            e.PreviousGesture,
            e.NewGesture);
    }

    private void ResetHotkeysButton_Click(object sender, RoutedEventArgs e)
    {
        var currentViewModel = viewModel ?? (sender as FrameworkElement)?.DataContext as MainViewModel;
        currentViewModel?.Settings.Hotkeys.ResetToDefaults();
    }

    private void MainWindowPreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        ReleaseNativeOverlayChatInputFocusForWpfTextInput(e.OriginalSource);

        if (Keyboard.FocusedElement is HotkeyRecorderButton recorder &&
            recorder.TryCaptureMouseButton(e.ChangedButton, Keyboard.Modifiers))
        {
            e.Handled = true;
            return;
        }

        if (viewModel?.IsStreamSearchPanelVisible != true)
        {
            return;
        }

        if (IsPointInsideElement(HomeSearchAnchor, e.GetPosition(HomeSearchAnchor)))
        {
            return;
        }

        viewModel.DismissStreamSearchDropdown();
    }

    private void MainWindowPreviewGotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
        ReleaseNativeOverlayChatInputFocusForWpfTextInput(e.NewFocus);
    }

    private void MainWindowPreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (Keyboard.FocusedElement is HotkeyRecorderButton recorder &&
            (recorder.TryCaptureMouseButton(e.ChangedButton, Keyboard.Modifiers, isRelease: true) ||
                recorder.IsCapturingInput && HotkeyGesture.IsBindableMouseButton(e.ChangedButton)))
        {
            e.Handled = true;
            return;
        }

        if (TryExecuteMouseHotkey(e.ChangedButton, Keyboard.Modifiers, Keyboard.FocusedElement))
        {
            e.Handled = true;
        }
    }

    internal bool TryExecuteNativeMouseAppCommand(IntPtr sourceWindow, IntPtr lParam)
    {
        // Native video children forward unhandled side-button releases as WM_APPCOMMAND.
        // WPF content handles PreviewMouseUp itself. Using the native message queue avoids
        // dropping a press when the UI is busier than the low-level hook's timeout.
        if (!IsActive || windowHandle == IntPtr.Zero || GetForegroundWindow() != windowHandle ||
            sourceWindow == windowHandle ||
            !WindowHitTestPolicy.IsWindowOwnedBy(windowHitTester, windowHandle, sourceWindow, includeOwnedPopups: false))
        {
            return false;
        }

        var value = unchecked((uint)lParam.ToInt64());
        var commandAndDevice = value >> 16;
        if ((commandAndDevice & 0xF000) != 0x8000) // FAPPCOMMAND_MOUSE
        {
            return false;
        }

        var button = (commandAndDevice & 0x0FFF) switch
        {
            1 => MouseButton.XButton1, // APPCOMMAND_BROWSER_BACKWARD
            2 => MouseButton.XButton2, // APPCOMMAND_BROWSER_FORWARD
            _ => (MouseButton?)null
        };
        if (button is not { } sideButton)
        {
            return false;
        }

        if (Keyboard.FocusedElement is HotkeyRecorderButton recorder &&
            (recorder.TryCaptureMouseButton(sideButton, Keyboard.Modifiers, isRelease: true) || recorder.IsCapturingInput))
        {
            return true;
        }

        var modifiers = Keyboard.Modifiers & (ModifierKeys.Alt | ModifierKeys.Windows);
        if ((value & 0x0008) != 0) modifiers |= ModifierKeys.Control;
        if ((value & 0x0004) != 0) modifiers |= ModifierKeys.Shift;
        return TryExecuteMouseHotkey(sideButton, modifiers, Keyboard.FocusedElement);
    }

    private void ReleaseNativeOverlayChatInputFocusForWpfTextInput(object? candidate)
    {
        if (!IsWpfTextInput(candidate))
        {
            return;
        }

        viewModel?.ReleaseNativeOverlayChatInputFocus();
    }

    private static bool IsWpfTextInput(object? candidate)
    {
        if (candidate is TextBoxBase or PasswordBox)
        {
            return true;
        }

        return candidate is DependencyObject dependencyObject &&
            (dependencyObject is Visual ||
                dependencyObject is System.Windows.Media.Media3D.Visual3D) &&
            (FindVisualParent<TextBoxBase>(dependencyObject) is not null ||
                FindVisualParent<PasswordBox>(dependencyObject) is not null);
    }

    internal bool TryExecuteMouseHotkey(MouseButton changedButton, ModifierKeys modifiers, IInputElement? focusedElement)
    {
        if (!HotkeyGesture.IsBindableMouseButton(changedButton))
        {
            return false;
        }

        if (focusedElement is HotkeyRecorderButton { IsCapturingInput: true } recorder)
        {
            return recorder.TryCaptureMouseButton(changedButton, modifiers);
        }

        return TryExecuteHotkey(HotkeyGesture.FromMouseButton(changedButton, modifiers), focusedElement);
    }

    private void MainWindowPreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (tabDetachDragTab is null && videoReorderDragTab is null)
        {
            return;
        }

        var screenPoint = PointToNativeScreenPoint(e.GetPosition(this));
        if (TryContinueVideoReorderDrag(screenPoint))
        {
            e.Handled = true;
            return;
        }

        if (tabDetachDragTab is null)
        {
            return;
        }

        if (TryContinueTabDetachDrag(screenPoint, continueDrag: true))
        {
            e.Handled = true;
        }
    }

    private void MainWindowPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        var screenPoint = PointToNativeScreenPoint(e.GetPosition(this));
        if (TryCompleteVideoReorderDrag(screenPoint))
        {
            e.Handled = true;
        }

        if (TryCompleteTabDetachDrag(screenPoint))
        {
            e.Handled = true;
        }

        ClearVideoReorderDrag();
        ClearTabDetachDrag();
    }

    private void HomeContentScrollViewer_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (homeAutoScrollViewer is not null)
        {
            if (e.ChangedButton == MouseButton.Middle)
            {
                ClearHomeAutoScroll();
                e.Handled = true;
            }

            return;
        }

        if (e.ChangedButton == MouseButton.Middle &&
            e.OriginalSource is DependencyObject streamSource &&
            TryHandleHomeStreamOpenAndStayOnHomeCommand(streamSource))
        {
            e.Handled = true;
            return;
        }

        if (e.ChangedButton != MouseButton.Middle ||
            sender is not ScrollViewer scrollViewer ||
            scrollViewer.ScrollableHeight <= 0 ||
            tabDetachDragTab is not null ||
            videoReorderDragTab is not null)
        {
            return;
        }

        if (e.OriginalSource is DependencyObject source && FindVisualParent<ScrollBar>(source) is not null)
        {
            return;
        }

        BeginHomeAutoScroll(scrollViewer, e.GetPosition(scrollViewer));
        e.Handled = homeAutoScrollViewer is not null;
    }

    private void HomeStreamItemButton_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Middle)
        {
            return;
        }

        var source = e.OriginalSource as DependencyObject ?? sender as DependencyObject;
        if (TryHandleHomeStreamOpenAndStayOnHomeCommand(source))
        {
            e.Handled = true;
        }
    }

    private void HomeContentScrollViewer_PreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (homeAutoScrollViewer is null)
        {
            return;
        }

        if (!HomeAutoScrollController.ShouldContinue(e.MiddleButton))
        {
            ClearHomeAutoScroll();
            e.Handled = true;
            return;
        }

        homeAutoScrollCursorPoint = e.GetPosition(homeAutoScrollViewer);
        e.Handled = true;
    }

    private void HomeContentScrollViewer_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (homeAutoScrollViewer is null || e.ChangedButton != MouseButton.Middle)
        {
            return;
        }

        ClearHomeAutoScroll();
        e.Handled = true;
    }

    private void HomeContentScrollViewer_LostMouseCapture(object sender, MouseEventArgs e)
    {
        if (ReferenceEquals(sender, homeAutoScrollViewer))
        {
            ClearHomeAutoScroll(releaseCapture: false);
        }
    }

    private void HomeContentScrollViewer_ScrollChanged(object sender, ScrollChangedEventArgs e)
    {
        TryLoadMoreBrowseCategories();
    }

    private void TryLoadMoreBrowseCategories()
    {
        if (pendingHomeScroll is not null ||
            viewModel?.IsBrowseCategoriesPageVisible != true ||
            viewModel.LoadMoreBrowseCategoriesCommand.CanExecute(null) != true ||
            !HomeAutoScrollController.IsNearBottom(
                HomeContentScrollViewer.VerticalOffset,
                HomeContentScrollViewer.ScrollableHeight,
                BrowseCategoryLoadMoreBottomThreshold))
        {
            return;
        }

        viewModel.LoadMoreBrowseCategoriesCommand.Execute(null);
    }

    private void BeginHomeAutoScroll(ScrollViewer scrollViewer, Point anchorPoint)
    {
        if (!Mouse.Capture(scrollViewer, CaptureMode.SubTree))
        {
            return;
        }

        homeAutoScrollViewer = scrollViewer;
        homeAutoScrollAnchorPoint = anchorPoint;
        homeAutoScrollCursorPoint = anchorPoint;
        homeAutoScrollPreviousCursor = Cursor;
        homeAutoScrollLastTickTimestamp = Stopwatch.GetTimestamp();
        Cursor = Cursors.ScrollNS;
        EnsureHomeAutoScrollTimer().Start();
    }

    private DispatcherTimer EnsureHomeAutoScrollTimer()
    {
        if (homeAutoScrollTimer is not null)
        {
            return homeAutoScrollTimer;
        }

        homeAutoScrollTimer = new DispatcherTimer(DispatcherPriority.Input, Dispatcher)
        {
            Interval = HomeAutoScrollInterval
        };
        homeAutoScrollTimer.Tick += HomeAutoScrollTimerOnTick;
        return homeAutoScrollTimer;
    }

    private void HomeAutoScrollTimerOnTick(object? sender, EventArgs e)
    {
        var scrollViewer = homeAutoScrollViewer;
        if (scrollViewer is null)
        {
            homeAutoScrollTimer?.Stop();
            return;
        }

        if (!HomeAutoScrollController.ShouldContinue(Mouse.MiddleButton))
        {
            ClearHomeAutoScroll();
            return;
        }

        var now = Stopwatch.GetTimestamp();
        var elapsedSeconds = homeAutoScrollLastTickTimestamp == 0
            ? HomeAutoScrollInterval.TotalSeconds
            : (now - homeAutoScrollLastTickTimestamp) / (double)Stopwatch.Frequency;
        homeAutoScrollLastTickTimestamp = now;

        var targetOffset = HomeAutoScrollController.GetVerticalOffset(
            scrollViewer.VerticalOffset,
            homeAutoScrollAnchorPoint.Y,
            homeAutoScrollCursorPoint.Y,
            scrollViewer.ScrollableHeight,
            elapsedSeconds);
        if (Math.Abs(targetOffset - scrollViewer.VerticalOffset) > double.Epsilon)
        {
            scrollViewer.ScrollToVerticalOffset(targetOffset);
        }
    }

    private void ClearHomeAutoScroll(bool releaseCapture = true)
    {
        var scrollViewer = homeAutoScrollViewer;
        if (scrollViewer is null)
        {
            return;
        }

        homeAutoScrollTimer?.Stop();
        homeAutoScrollViewer = null;
        homeAutoScrollAnchorPoint = default;
        homeAutoScrollCursorPoint = default;
        homeAutoScrollLastTickTimestamp = 0;
        Cursor = homeAutoScrollPreviousCursor;
        homeAutoScrollPreviousCursor = null;

        if (releaseCapture && ReferenceEquals(Mouse.Captured, scrollViewer))
        {
            Mouse.Capture(null);
        }
    }

    internal static bool TryHandleHomeStreamOpenAndStayOnHomeCommand(DependencyObject? source)
    {
        if (!TryResolveHomeStreamOpenAndStayOnHomeCommand(source, out var command))
        {
            return false;
        }

        if (command.CanExecute(null))
        {
            command.Execute(null);
        }

        return true;
    }

    internal static bool TryResolveHomeStreamOpenAndStayOnHomeCommand(
        DependencyObject? source,
        out AsyncRelayCommand command)
    {
        command = null!;
        var button = source as Button ?? (source is null ? null : FindVisualParent<Button>(source));
        if (button?.DataContext is not IHomeStreamOpenItemViewModel item ||
            !IsHomeStreamOpenButton(button))
        {
            return false;
        }

        command = item.OpenAndStayOnHomeCommand;
        return true;
    }

    private static bool IsHomeStreamOpenButton(Button button)
    {
        var binding = BindingOperations.GetBindingExpression(button, ButtonBase.CommandProperty);
        return string.Equals(binding?.ParentBinding.Path?.Path, "OpenCommand", StringComparison.Ordinal);
    }

    private async void MainWindowLoaded(object sender, RoutedEventArgs e)
    {
        Loaded -= MainWindowLoaded;

        var logger = new FileAppLogger();
        appLogger = logger;
        try
        {
            await InitializeMainWindowAsync(logger);
        }
        catch (Exception ex)
        {
            logger.Write(AppLogLevel.Error, "Startup", "Application startup failed.", ex);
            if (!shutdownStarted)
            {
                exitRequested = true;
                Close();
            }
        }
    }

    private async Task InitializeMainWindowAsync(IAppLogger logger)
    {
        var jsonSettingsService = new JsonSettingsService();
        settingsService = jsonSettingsService;
        var settings = await jsonSettingsService.LoadAsync();
        var settingsLoadWarning = jsonSettingsService.LastLoadWarning;
        if (!string.IsNullOrWhiteSpace(settingsLoadWarning))
        {
            logger.Write(AppLogLevel.Warning, "Settings", settingsLoadWarning);
        }
        if (shutdownStarted)
        {
            return;
        }

        ThemeManager.ApplyTheme(settings.Theme);

        settings.StreamlinkPath ??= ExecutableResolver.FindStreamlink();
        settings.VlcDirectory ??= ExecutableResolver.FindVlcDirectory();

        var streamlinkService = new StreamlinkService(logger);
        // Twitch VODs with muted segments freeze libVLC; the gateway routes only those through a
        // local repair proxy. It outlives the tabs, so it is disposed after the view model.
        var mutedVodPlaybackGateway = new TwitchMutedVodPlaybackGateway(logger);
        twitchMutedVodPlaybackGateway = mutedVodPlaybackGateway;
        var playbackFactory = new LibVlcPlaybackEngineFactory(logger, settings.Chat, mutedVodPlaybackGateway);
        var chatFactory = new ChatClientFactory(settings, logger);
        var viewerCountService = new ViewerCountService(logger);
        var replayResolver = new ReplayResolver(logger, streamlinkService);
        var vodChatProvider = new VodChatProvider(logger);
        var followedStreamsService = new FollowedStreamsService(logger);
        var streamMetadataService = new StreamMetadataService(logger);
        var streamSearchService = new StreamSearchService(logger, streamlinkService);
        var twitchVodService = new TwitchVodService(logger);
        var twitchSubOnlyVodResolver = new TwitchSubOnlyVodResolver(logger);
        var twitchClipService = new TwitchClipService();
        var kickVodService = new KickVodService(logger);
        var browseService = new BrowseService(logger);
        var liveNotificationService = new ToastLiveNotificationService(logger);
        var appUpdateService = new StagedAppUpdateService(logger);
        this.liveNotificationService = liveNotificationService;
        liveNotificationService.Activated += OnLiveNotificationActivated;

        viewModel = new MainViewModel(new MainViewModelDependencies
        {
            Settings = settings,
            SettingsService = settingsService,
            StreamlinkService = streamlinkService,
            PlaybackFactory = playbackFactory,
            ChatFactory = chatFactory,
            Logger = logger,
            Dispatch = DispatchToUi,
            ViewerCountService = viewerCountService,
            FollowedStreamsService = followedStreamsService,
            KickFollowedChannelsImporter = new Kick.KickFollowedChannelsImporter(this),
            StreamMetadataService = streamMetadataService,
            ReplayResolver = replayResolver,
            VodChatProvider = vodChatProvider,
            VodPlaybackHistory = new JsonVodPlaybackHistory(
                Path.Combine(Path.GetDirectoryName(settingsService.SettingsPath)!, "vod-history.json"), logger),
            TwitchVodService = twitchVodService,
            BrowseService = browseService,
            StreamSearchService = streamSearchService,
            KickVodService = kickVodService,
            LiveNotificationService = liveNotificationService,
            TwitchSubOnlyVodResolver = twitchSubOnlyVodResolver,
            TwitchClipService = twitchClipService,
            KickClipService = new Kick.KickClipService(this),
            AppUpdateService = appUpdateService,
            RequestShutdown = RequestApplicationExit,
            TryDispatch = TryDispatchToUi
        });

        viewModel.Initialize();
        twitchChannelPoints = new TwitchChannelPointsController(
            settings, viewModel.Tabs, () => viewModel.SelectedTab, new TwitchBonusBrowser(this), logger,
            settingsService: settingsService);
        TwitchBonusesPanel.DataContext = twitchChannelPoints;
        if (!string.IsNullOrWhiteSpace(settingsLoadWarning))
        {
            viewModel.SetStartupWarning(settingsLoadWarning);
        }
        viewModel.Tabs.CollectionChanged += ViewModelTabsCollectionChanged;
        DataContext = viewModel;

        if (setupRequested || !settings.SetupCompleted)
        {
            var setupWizard = new SetupWizardWindow(settings, settingsService, logger)
            {
                Owner = this
            };
            setupWizard.ShowDialog();
        }
    }

    private async void MainWindowClosing(object? sender, CancelEventArgs e)
    {
        // Clear this while the HWND is still valid. The close can be deferred for asynchronous
        // shutdown or converted into a tray hide, and either path must release shell fullscreen.
        ClearTaskbarFullscreen();

        if (closeConfirmed)
        {
            return;
        }

        e.Cancel = true;
        if (!exitRequested)
        {
            if (viewModel?.Settings.CloseBehavior == WindowCloseBehavior.MinimizeToTray)
            {
                HideToTray();
                return;
            }

            exitRequested = true;
        }

        if (shutdownStarted)
        {
            Environment.Exit(0);
            return;
        }

        shutdownStarted = true;
        twitchChannelPoints?.Dispose();
        twitchChannelPoints = null;
        Hide();
        DisposeTrayIcon();
        var forceExit = false;

        try
        {
            if (viewModel is not null)
            {
                CloseAllDetachedWindows(reattach: false);
                viewModel.Tabs.CollectionChanged -= ViewModelTabsCollectionChanged;

                await viewModel.DisposeAsync().AsTask().WaitAsync(ShutdownTimeout);
                if (settingsService is not null)
                {
                    await settingsService.SaveAsync(viewModel.Settings).WaitAsync(ShutdownTimeout);
                }
            }
        }
        catch (Exception)
        {
            // Shutdown must still complete even if a stream/chat backend refuses to stop.
            forceExit = true;
        }
        finally
        {
            // After the tabs, whose playback engines hold its sessions -- and outside the block
            // above, so a startup failure (no view model) cannot leak it and a proxy that will not
            // stop cannot keep the settings from being saved.
            await DisposeMutedVodPlaybackGatewayAsync();
            await DisposeAppLoggerAsync();
            closeConfirmed = true;
            // Null-conditional: test hosts close this window on a bare STA dispatcher
            // without a WPF Application instance.
            Application.Current?.Shutdown();
            if (forceExit)
            {
                Environment.Exit(0);
            }
        }
    }

    private void MainWindowClosed(object? sender, EventArgs e)
    {
        twitchChannelPoints?.Dispose();
        twitchChannelPoints = null;
        ClearTaskbarFullscreen();

        if (viewModel is not null)
        {
            viewModel.Tabs.CollectionChanged -= ViewModelTabsCollectionChanged;
        }

        CloseAllDetachedWindows(reattach: false);
        ClearHomeAutoScroll();
        UninstallMouseWheelHook();
        StopVideoReorderPolling();
        if (liveNotificationService is not null)
        {
            liveNotificationService.Activated -= OnLiveNotificationActivated;
            liveNotificationService.Dispose();
            liveNotificationService = null;
        }

        DisposeTrayIcon();
        dockedChatController.Dispose();
        pictureInPicture.Dispose();
        windowMode.Dispose();
    }

    private async Task DisposeMutedVodPlaybackGatewayAsync()
    {
        var gateway = twitchMutedVodPlaybackGateway;
        twitchMutedVodPlaybackGateway = null;
        if (gateway is null)
        {
            return;
        }

        try
        {
            await gateway.DisposeAsync().AsTask().WaitAsync(ShutdownTimeout);
        }
        catch (Exception ex)
        {
            // Its connections run on pool threads, so a proxy that will not stop cannot keep the
            // process alive; record it and let shutdown continue.
            appLogger?.Write(AppLogLevel.Warning, "Shutdown", "The muted VOD repair proxy did not stop cleanly.", ex);
        }
    }

    private async Task DisposeAppLoggerAsync()
    {
        var logger = appLogger;
        appLogger = null;
        try
        {
            if (logger is IAsyncDisposable asyncDisposable)
            {
                await asyncDisposable.DisposeAsync().AsTask().WaitAsync(ShutdownTimeout);
            }
            else if (logger is IDisposable disposable)
            {
                disposable.Dispose();
            }
        }
        catch (Exception ex) when (ex is TimeoutException or IOException or UnauthorizedAccessException)
        {
            // Shutdown must remain bounded even if the filesystem is no longer writable.
        }
    }

    private void OnLiveNotificationActivated(NotificationActivation activation)
    {
        DispatchToUi(() =>
        {
            RestoreFromNotification();
            viewModel?.OpenChannelFromNotification(activation.Platform, activation.Channel);
        });
    }

    private void RestoreFromNotification()
    {
        ShowInTaskbar = true;
        if (!IsVisible)
        {
            Show();
        }

        if (WindowState == WindowState.Minimized)
        {
            WindowState = WindowState.Normal;
        }

        Activate();
        Topmost = true;
        Topmost = false;
        Focus();
    }

    private void DispatchToUi(Action action)
    {
        _ = TryDispatchToUi(action);
    }

    private bool TryDispatchToUi(Action action)
    {
        ArgumentNullException.ThrowIfNull(action);
        if (Dispatcher.HasShutdownStarted || Dispatcher.HasShutdownFinished)
        {
            return false;
        }

        try
        {
            _ = Dispatcher.BeginInvoke(DispatcherPriority.Background, action);
            return true;
        }
        catch (InvalidOperationException)
        {
            return false;
        }
        catch (TaskCanceledException)
        {
            return false;
        }
    }

    private void VideoSurface_Loaded(object sender, RoutedEventArgs e)
    {
        if (sender is VideoSurface surface && surface.Tag is StreamTabViewModel tab)
        {
            videoSurfaces[tab] = surface;
            surface.NativeMouseLeftButtonDown += VideoSurface_NativeMouseLeftButtonDown;
            surface.NativeMouseMoved += VideoSurface_NativeMouseMoved;
            surface.NativeMouseLeftButtonUp += VideoSurface_NativeMouseLeftButtonUp;
            tab.PropertyChanged -= MainVideoTabOnPropertyChanged;
            tab.PropertyChanged += MainVideoTabOnPropertyChanged;
            tab.SetVideoHandle(surface.Handle);
        }
    }

    private void VideoSurface_Unloaded(object sender, RoutedEventArgs e)
    {
        if (sender is VideoSurface surface && surface.Tag is StreamTabViewModel tab &&
            videoSurfaces.TryGetValue(tab, out var trackedSurface) &&
            ReferenceEquals(surface, trackedSurface))
        {
            surface.NativeMouseLeftButtonDown -= VideoSurface_NativeMouseLeftButtonDown;
            surface.NativeMouseMoved -= VideoSurface_NativeMouseMoved;
            surface.NativeMouseLeftButtonUp -= VideoSurface_NativeMouseLeftButtonUp;
            tab.PropertyChanged -= MainVideoTabOnPropertyChanged;
            videoSurfaces.Remove(tab);
            tab.ClearVideoHandle(surface.Handle);
        }
    }

    private void MainVideoTabOnPropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(StreamTabViewModel.Status) &&
            sender is StreamTabViewModel { Status: PlaybackStatus.Starting or PlaybackStatus.Playing } tab &&
            videoSurfaces.TryGetValue(tab, out var surface))
        {
            surface.ScheduleRendererWindowRepair();
        }
    }

    private void VideoSurface_MouseLeftButtonPressed(object? sender, EventArgs e)
    {
        if (sender is FrameworkElement { Tag: StreamTabViewModel tab } && viewModel is not null)
        {
            viewModel.SelectedTab = tab;
        }
    }

    private void VideoSurface_NativeMouseLeftButtonDown(object? sender, VideoSurfaceNativeMouseEventArgs e)
    {
        if (sender is FrameworkElement { Tag: StreamTabViewModel tab } && viewModel is not null)
        {
            viewModel.SelectedTab = tab;
        }

        _ = BeginVideoReorderDragCandidate(new NativePoint(e.ScreenX, e.ScreenY));
    }

    private void VideoSurface_NativeMouseMoved(object? sender, VideoSurfaceNativeMouseEventArgs e)
    {
        if (TryContinueVideoReorderDrag(new NativePoint(e.ScreenX, e.ScreenY)) && videoReorderDragStarted)
        {
            e.Handled = true;
        }
    }

    private void VideoSurface_NativeMouseLeftButtonUp(object? sender, VideoSurfaceNativeMouseEventArgs e)
    {
        if (TryCompleteVideoReorderDrag(new NativePoint(e.ScreenX, e.ScreenY)))
        {
            e.Handled = true;
            return;
        }

        ClearVideoReorderDrag();
    }

    private void CloseTabButton_Click(object sender, RoutedEventArgs e)
    {
        if (viewModel is null)
        {
            return;
        }

        if ((sender as FrameworkElement)?.Tag is TabStripItemViewModel item)
        {
            viewModel.CloseTabStripItem(item);
        }
        else if ((sender as FrameworkElement)?.Tag is StreamTabViewModel tab)
        {
            viewModel.CloseTab(tab);
        }
    }

    private void TabContent_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.OriginalSource is DependencyObject source && FindVisualParent<Button>(source) is not null)
        {
            return;
        }

        var startedWithControlModifier = isControlModifierPressed();
        var sourceElement = sender as FrameworkElement;
        if (sourceElement?.DataContext is TabStripItemViewModel item)
        {
            if (viewModel is not null && TabsContainActiveTab(item))
            {
                viewModel.SelectedTab = item.ActiveTab;
                TabListBox.SelectedItem = viewModel.SelectedTabStripItem;
            }
            else
            {
                TabListBox.SelectedItem = item;
            }

            BeginTabDetachDrag(
                sourceElement,
                item.ActiveTab,
                item.Tabs,
                e.GetPosition(this),
                startedWithControlModifier);
            e.Handled = true;
        }
        else if (sourceElement?.DataContext is StreamTabViewModel tab)
        {
            if (viewModel is not null)
            {
                viewModel.SelectedTab = tab;
                TabListBox.SelectedItem = viewModel.SelectedTabStripItem;
            }
            else
            {
                TabListBox.SelectedItem = tab;
            }

            BeginTabDetachDrag(
                sourceElement,
                tab,
                [tab],
                e.GetPosition(this),
                startedWithControlModifier);
            e.Handled = true;
        }
    }

    private bool TabsContainActiveTab(TabStripItemViewModel item)
    {
        return viewModel?.Tabs.Contains(item.ActiveTab) == true;
    }

    private void BeginTabDetachDrag(
        FrameworkElement? source,
        StreamTabViewModel tab,
        IReadOnlyList<StreamTabViewModel> draggedTabs,
        Point startPoint,
        bool startedWithControlModifier)
    {
        if (source is null)
        {
            return;
        }

        if (PresentationSource.FromVisual(this) is not null)
        {
            Mouse.Capture(this, CaptureMode.SubTree);
        }

        tabDetachDragSource = source;
        tabDetachDragTab = tab;
        tabDetachDragMergeTarget = null;
        tabDetachDragTabs = draggedTabs
            .Where(candidate => viewModel?.Tabs.Contains(candidate) == true)
            .Distinct()
            .ToArray();
        tabDetachDragStartPoint = startPoint;
        tabDetachDragStartScreenPoint = PointToNativeScreenPoint(startPoint);
        tabStripReorderDragReordered = false;
        tabDetachDragStartedWithControlModifier = startedWithControlModifier;
        UpdateLowLevelMouseMoveRouteState();
    }

    private void ClearTabDetachDrag()
    {
        if (ReferenceEquals(Mouse.Captured, this) && videoReorderDragTab is null)
        {
            Mouse.Capture(null);
        }

        tabDetachDragSource = null;
        tabDetachDragTab = null;
        tabDetachDragMergeTarget = null;
        tabDetachDragTabs = [];
        tabDetachDragStartPoint = default;
        tabDetachDragStartScreenPoint = default;
        tabStripReorderDragReordered = false;
        tabDetachDragStartedWithControlModifier = false;
        if (videoReorderDragTab is null)
        {
            Cursor = null;
        }

        UpdateLowLevelMouseMoveRouteState();
    }

    private bool BeginVideoReorderDragCandidate(NativePoint screenPoint)
    {
        ClearVideoReorderDrag();
        if (viewModel is null ||
            GetVideoTabAtScreenPoint(screenPoint) is not { } tab ||
            !viewModel.CanReorderVisibleVideoTab(tab) ||
            IsScreenPointOverNativeOverlay(tab, screenPoint))
        {
            return false;
        }

        videoReorderDragTab = tab;
        videoReorderDragStartScreenPoint = screenPoint;
        videoReorderDragStarted = false;
        videoReorderDragReordered = false;
        Mouse.Capture(this, CaptureMode.SubTree);
        StartVideoReorderPolling();
        UpdateLowLevelMouseMoveRouteState();
        return true;
    }

    private void ClearVideoReorderDrag()
    {
        if (ReferenceEquals(Mouse.Captured, this) && tabDetachDragTab is null)
        {
            Mouse.Capture(null);
        }

        videoReorderDragTab = null;
        videoReorderDragStartScreenPoint = default;
        videoReorderDragStarted = false;
        videoReorderDragReordered = false;
        Cursor = null;
        UpdateLowLevelMouseMoveRouteState();
    }

    private void UpdateLowLevelMouseMoveRouteState()
    {
        hasActiveLowLevelMouseMoveRoute =
            tabDetachDragTab is not null ||
            videoReorderDragTab is not null ||
            detachedWindows.Values.Distinct().Any(window => window.HasVideoMoveCandidate);
    }

    private void StartVideoReorderPolling()
    {
        if (videoReorderPollTimer is not null)
        {
            if (!videoReorderPollTimer.IsEnabled)
            {
                videoReorderPollTimer.Start();
            }

            return;
        }

        videoReorderPollTimer = new DispatcherTimer(DispatcherPriority.Input, Dispatcher)
        {
            Interval = TimeSpan.FromMilliseconds(VideoReorderPollIntervalMilliseconds)
        };
        videoReorderPollTimer.Tick += VideoReorderPollTimerOnTick;
        videoReorderPollTimer.Start();
    }

    private void StopVideoReorderPolling()
    {
        if (videoReorderPollTimer is null)
        {
            return;
        }

        videoReorderPollTimer.Stop();
        videoReorderPollTimer.Tick -= VideoReorderPollTimerOnTick;
        videoReorderPollTimer = null;
    }

    private void VideoReorderPollTimerOnTick(object? sender, EventArgs e)
    {
        var leftButtonPressed = isLeftMouseButtonPressed();
        if (getVideoReorderCursorScreenPoint() is not { } screenPoint)
        {
            videoReorderPollLeftButtonWasPressed = leftButtonPressed;
            if (!leftButtonPressed && videoReorderDragTab is not null)
            {
                ClearVideoReorderDrag();
            }

            return;
        }

        PollVideoReorderDrag(screenPoint, leftButtonPressed);
    }

    private void PollVideoReorderDrag(NativePoint screenPoint, bool leftButtonPressed)
    {
        var leftButtonWasPressed = videoReorderPollLeftButtonWasPressed;
        videoReorderPollLeftButtonWasPressed = leftButtonPressed;

        if (viewModel is null)
        {
            ClearVideoReorderDrag();
            return;
        }

        if (videoReorderDragTab is null)
        {
            if (leftButtonPressed && !leftButtonWasPressed && IsActive)
            {
                _ = BeginVideoReorderDragCandidate(screenPoint);
            }

            return;
        }

        if (leftButtonPressed)
        {
            _ = TryContinueVideoReorderDrag(screenPoint, leftButtonPressed: true);
            return;
        }

        if (!TryCompleteVideoReorderDrag(screenPoint))
        {
            ClearVideoReorderDrag();
        }
    }

    private bool TryContinueVideoReorderDrag(NativePoint screenPoint)
    {
        return TryContinueVideoReorderDrag(screenPoint, isLeftMouseButtonPressed());
    }

    private bool TryContinueVideoReorderDrag(NativePoint screenPoint, bool leftButtonPressed)
    {
        if (viewModel is null ||
            videoReorderDragTab is not { } draggedTab)
        {
            ClearVideoReorderDrag();
            return false;
        }

        if (!leftButtonPressed)
        {
            ClearVideoReorderDrag();
            return false;
        }

        if (!viewModel.CanReorderVisibleVideoTab(draggedTab))
        {
            ClearVideoReorderDrag();
            return false;
        }

        if (!videoReorderDragStarted)
        {
            if (!HasExceededDragDistance(videoReorderDragStartScreenPoint, screenPoint))
            {
                return false;
            }

            videoReorderDragStarted = true;
            viewModel.SelectedTab = draggedTab;
            ResetVideoDoubleClickTracking();
            Cursor = Cursors.SizeAll;
        }

        if (GetVideoReorderDropTarget(screenPoint, draggedTab) is { } dropTab)
        {
            _ = TryReorderDraggedVideoTab(draggedTab, dropTab);
        }

        return true;
    }

    private bool TryCompleteVideoReorderDrag(NativePoint screenPoint)
    {
        if (viewModel is null ||
            videoReorderDragTab is not { } draggedTab ||
            !videoReorderDragStarted)
        {
            return false;
        }

        if (!videoReorderDragReordered &&
            GetVideoReorderDropTarget(screenPoint, draggedTab) is { } dropTab)
        {
            _ = TryReorderDraggedVideoTab(draggedTab, dropTab);
        }

        ClearVideoReorderDrag();
        return true;
    }

    private bool TryReorderDraggedVideoTab(StreamTabViewModel draggedTab, StreamTabViewModel dropTab)
    {
        if (viewModel?.TryReorderVisibleVideoTab(draggedTab, dropTab) != true)
        {
            return false;
        }

        videoReorderDragReordered = true;
        VideoViewport.UpdateLayout();
        return true;
    }

    private StreamTabViewModel? GetVideoReorderDropTarget(NativePoint screenPoint, StreamTabViewModel draggedTab)
    {
        if (viewModel is null ||
            GetVideoTabAtScreenPoint(screenPoint) is not { } targetTab ||
            ReferenceEquals(targetTab, draggedTab) ||
            !viewModel.CanReorderVisibleVideoTab(targetTab))
        {
            return null;
        }

        return targetTab;
    }

    private bool IsScreenPointOverNativeOverlay(StreamTabViewModel tab, NativePoint screenPoint)
    {
        return videoSurfaces.TryGetValue(tab, out var surface) &&
            IsScreenPointOverElement(surface, screenPoint) &&
            IsPointerOverNativeOverlay(tab);
    }

    private bool IsPointerOverNativeOverlay(StreamTabViewModel tab)
    {
        return viewModel?.Settings.Chat.Layout == ChatLayout.Overlay &&
            tab.IsChatVisible &&
            !tab.IsDockedChatOverrideActive &&
            tab.UsesNativeOverlay &&
            TryGetVideoCursorPoint(tab, out var videoPoint, out _, out var videoHeight) &&
            TryGetNativeOverlayBounds(tab, videoHeight, out var overlayBounds) &&
            overlayBounds.Contains(videoPoint);
    }

    private bool TryContinueTabDetachDrag(NativePoint screenPoint, bool continueDrag)
    {
        if (viewModel is null ||
            tabDetachDragTab is not { } tab ||
            tabDetachDragSource is null)
        {
            ClearTabDetachDrag();
            return false;
        }

        if (!isLeftMouseButtonPressed())
        {
            ClearTabDetachDrag();
            return false;
        }

        if (!HasExceededTabDetachDragDistance(screenPoint))
        {
            return false;
        }

        var isControlDrag = tabDetachDragStartedWithControlModifier || isControlModifierPressed();
        var isOutsideTabStrip = IsScreenPointOutsideTabStrip(screenPoint);
        if (!isControlDrag && !isOutsideTabStrip)
        {
            tabDetachDragMergeTarget = null;
            Cursor = Cursors.SizeAll;
            _ = TryReorderDraggedTabStripTabs(screenPoint, tab);
            return true;
        }

        if (TryAttachDraggedTabToPictureInPictureTarget(screenPoint, tab))
        {
            ClearTabDetachDrag();
            return true;
        }

        if (!isOutsideTabStrip)
        {
            if (isControlDrag)
            {
                UpdateTabDetachDragMergeTarget(screenPoint, tab);
            }

            return true;
        }

        ClearTabDetachDrag();
        DetachTabToPictureInPicture(tab, new Point(screenPoint.X, screenPoint.Y), continueDrag);
        return true;
    }

    private bool TryCompleteTabDetachDrag(NativePoint screenPoint)
    {
        if (viewModel is null ||
            tabDetachDragTab is not { } tab ||
            !HasExceededTabDetachDragDistance(screenPoint))
        {
            return false;
        }

        var isControlDrag = tabDetachDragStartedWithControlModifier || isControlModifierPressed();
        var isOutsideTabStrip = IsScreenPointOutsideTabStrip(screenPoint);
        if (!isControlDrag && !isOutsideTabStrip)
        {
            Cursor = Cursors.SizeAll;
            if (!tabStripReorderDragReordered)
            {
                _ = TryReorderDraggedTabStripTabs(screenPoint, tab);
            }

            return true;
        }

        if (TryAttachDraggedTabToPictureInPictureTarget(screenPoint, tab))
        {
            return true;
        }

        var hasTargetItem = TryGetTabStripItemAtScreenPoint(screenPoint, out var targetItem);
        if (isControlDrag &&
            hasTargetItem &&
            targetItem is not null)
        {
            if (TryMergeDraggedTabIntoMultiViewTarget(tab, targetItem))
            {
                return true;
            }

            tabDetachDragMergeTarget = null;
        }
        else if (isControlDrag && TryMergeDraggedTabIntoRememberedMultiViewTarget(tab))
        {
            return true;
        }

        var draggedTabs = GetTabDetachDragTabs(tab);
        if (isOutsideTabStrip &&
            HasPotentialPictureInPictureDropTarget(draggedTabs))
        {
            DetachTabToPictureInPicture(tab, new Point(screenPoint.X, screenPoint.Y), continueDrag: false);
            return true;
        }

        return false;
    }

    private bool TryReorderDraggedTabStripTabs(NativePoint screenPoint, StreamTabViewModel activeDraggedTab)
    {
        if (viewModel is null)
        {
            return false;
        }

        var draggedTabs = GetTabDetachDragTabs(activeDraggedTab);
        if (draggedTabs.Length == 0 ||
            !TryGetTabStripReorderTarget(
                screenPoint,
                out var targetTab,
                out var insertAfterTarget))
        {
            return false;
        }

        if (!viewModel.TryReorderTabStripTabs(
            draggedTabs,
            targetTab,
            insertAfterTarget,
            activeDraggedTab))
        {
            return false;
        }

        tabStripReorderDragReordered = true;
        TabListBox.UpdateLayout();
        VideoViewport.UpdateLayout();
        return true;
    }

    private bool TryAttachDraggedTabToPictureInPictureTarget(NativePoint screenPoint, StreamTabViewModel tab)
    {
        var draggedTabs = GetTabDetachDragTabs(tab);
        if (draggedTabs.Length == 0)
        {
            return false;
        }

        var targetWindow = GetPictureInPictureDropTarget(screenPoint, draggedTabs);
        return targetWindow is not null &&
            AddTabsToPictureInPictureWindow(targetWindow, draggedTabs, tab);
    }

    private void UpdateTabDetachDragMergeTarget(NativePoint screenPoint, StreamTabViewModel tab)
    {
        tabDetachDragMergeTarget = TryGetValidTabStripMergeTarget(screenPoint, tab, out var targetTab)
            ? targetTab
            : null;
    }

    private bool TryGetValidTabStripMergeTarget(
        NativePoint screenPoint,
        StreamTabViewModel tab,
        out StreamTabViewModel targetTab)
    {
        targetTab = null!;
        var draggedTabs = GetTabDetachDragTabs(tab);
        if (viewModel is null ||
            draggedTabs.Length == 0 ||
            !TryGetTabStripItemAtScreenPoint(screenPoint, out var targetItem) ||
            targetItem is null)
        {
            return false;
        }

        var draggedSet = draggedTabs.ToHashSet();
        if (targetItem.Tabs.Any(draggedSet.Contains) ||
            !viewModel.Tabs.Contains(targetItem.ActiveTab) ||
            targetItem.ActiveTab.IsDetached ||
            draggedTabs.Any(candidate => !viewModel.Tabs.Contains(candidate) || candidate.IsDetached) ||
            (draggedTabs.Length == 1 && draggedTabs[0].IsMergedTabGroupMember))
        {
            return false;
        }

        targetTab = targetItem.ActiveTab;
        return true;
    }

    private bool TryMergeDraggedTabIntoMultiViewTarget(
        StreamTabViewModel tab,
        TabStripItemViewModel targetItem)
    {
        var draggedTabs = GetTabDetachDragTabs(tab);
        return viewModel is not null &&
            draggedTabs.Length > 0 &&
            TryMergeTabsIntoMultiViewTabs(draggedTabs, tab, targetItem.ActiveTab);
    }

    private bool TryMergeDraggedTabIntoRememberedMultiViewTarget(StreamTabViewModel tab)
    {
        if (tabDetachDragMergeTarget is not { } targetTab)
        {
            return false;
        }

        var draggedTabs = GetTabDetachDragTabs(tab);
        if (viewModel is null ||
            draggedTabs.Length == 0 ||
            !viewModel.Tabs.Contains(targetTab) ||
            !TryMergeTabsIntoMultiViewTabs(draggedTabs, tab, targetTab))
        {
            tabDetachDragMergeTarget = null;
            return false;
        }

        return true;
    }

    internal bool TryMergeTabsIntoMultiViewTabs(
        IReadOnlyList<StreamTabViewModel> draggedTabs,
        StreamTabViewModel activeDraggedTab,
        StreamTabViewModel targetTab)
    {
        if (viewModel?.TryMergeTabsIntoMultiView(draggedTabs, targetTab, activeDraggedTab) != true)
        {
            return false;
        }

        VideoViewport.UpdateLayout();
        return true;
    }

    internal bool AddTabsToPictureInPictureWindow(DetachedVideoWindow targetWindow, IReadOnlyList<StreamTabViewModel> tabs, StreamTabViewModel? activeTab) => pictureInPicture.AddTabsToPictureInPictureWindow(targetWindow, tabs, activeTab);

    internal StreamTabViewModel[] GetPictureInPictureDragTabs(StreamTabViewModel tab) => pictureInPicture.GetPictureInPictureDragTabs(tab);

    private StreamTabViewModel[] GetTabDetachDragTabs(StreamTabViewModel tab)
    {
        if (viewModel is null)
        {
            return [];
        }

        var capturedTabs = tabDetachDragTabs
            .Where(viewModel.Tabs.Contains)
            .Distinct()
            .ToArray();
        return capturedTabs.Length > 0
            ? capturedTabs
            : GetPictureInPictureDragTabs(tab);
    }

    internal DetachedVideoWindow? GetPictureInPictureDropTarget(NativePoint screenPoint, IReadOnlyCollection<StreamTabViewModel> draggedTabs) => pictureInPicture.GetPictureInPictureDropTarget(screenPoint, draggedTabs);

    private bool TryGetTabAtTabStripScreenPoint(NativePoint screenPoint, out StreamTabViewModel? tab)
    {
        if (TryGetTabStripItemAtScreenPoint(screenPoint, out var item) && item is not null)
        {
            tab = item.ActiveTab;
            return true;
        }

        tab = null;
        return false;
    }

    private bool TryGetTabStripReorderTarget(
        NativePoint screenPoint,
        out StreamTabViewModel targetTab,
        out bool insertAfterTarget)
    {
        targetTab = null!;
        insertAfterTarget = false;

        if (!IsScreenPointOverElement(TabListBox, screenPoint))
        {
            return false;
        }

        var candidates = GetVisibleTabStripItemBounds().ToArray();
        if (candidates.Length == 0)
        {
            return false;
        }

        foreach (var candidate in candidates)
        {
            if (screenPoint.X < candidate.Left ||
                screenPoint.X >= candidate.Right ||
                screenPoint.Y < candidate.Top ||
                screenPoint.Y >= candidate.Bottom)
            {
                continue;
            }

            targetTab = candidate.Item.ActiveTab;
            insertAfterTarget = screenPoint.X >= candidate.Left + ((candidate.Right - candidate.Left) / 2);
            return true;
        }

        var first = candidates[0];
        if (screenPoint.X < first.Left)
        {
            targetTab = first.Item.ActiveTab;
            insertAfterTarget = false;
            return true;
        }

        var last = candidates[^1];
        if (screenPoint.X >= last.Right)
        {
            targetTab = last.Item.ActiveTab;
            insertAfterTarget = true;
            return true;
        }

        double? nearestDistance = null;
        TabStripItemViewModel? nearestItem = null;
        var nearestInsertAfter = false;
        foreach (var candidate in candidates)
        {
            var distanceToLeft = Math.Abs(screenPoint.X - candidate.Left);
            if (nearestDistance is null || distanceToLeft < nearestDistance)
            {
                nearestDistance = distanceToLeft;
                nearestItem = candidate.Item;
                nearestInsertAfter = false;
            }

            var distanceToRight = Math.Abs(screenPoint.X - candidate.Right);
            if (distanceToRight < nearestDistance)
            {
                nearestDistance = distanceToRight;
                nearestItem = candidate.Item;
                nearestInsertAfter = true;
            }
        }

        if (nearestItem is null)
        {
            return false;
        }

        targetTab = nearestItem.ActiveTab;
        insertAfterTarget = nearestInsertAfter;
        return true;
    }

    private IEnumerable<TabStripItemBounds> GetVisibleTabStripItemBounds()
    {
        foreach (var item in TabListBox.Items)
        {
            if (TabListBox.ItemContainerGenerator.ContainerFromItem(item) is not ListBoxItem listBoxItem ||
                listBoxItem.DataContext is not TabStripItemViewModel targetItem ||
                !listBoxItem.IsVisible ||
                listBoxItem.ActualWidth <= 0 ||
                listBoxItem.ActualHeight <= 0)
            {
                continue;
            }

            var topLeft = listBoxItem.PointToScreen(new Point(0, 0));
            var bottomRight = listBoxItem.PointToScreen(new Point(listBoxItem.ActualWidth, listBoxItem.ActualHeight));
            yield return new TabStripItemBounds(
                targetItem,
                Math.Min(topLeft.X, bottomRight.X),
                Math.Max(topLeft.X, bottomRight.X),
                Math.Min(topLeft.Y, bottomRight.Y),
                Math.Max(topLeft.Y, bottomRight.Y));
        }
    }

    private bool TryGetTabStripItemAtScreenPoint(NativePoint screenPoint, out TabStripItemViewModel? tabStripItem)
    {
        tabStripItem = null;
        if (!TabListBox.IsVisible ||
            TabListBox.ActualWidth <= 0 ||
            TabListBox.ActualHeight <= 0)
        {
            return false;
        }

        foreach (var item in TabListBox.Items)
        {
            if (TabListBox.ItemContainerGenerator.ContainerFromItem(item) is not ListBoxItem listBoxItem ||
                listBoxItem.DataContext is not TabStripItemViewModel targetItem ||
                !listBoxItem.IsVisible ||
                listBoxItem.ActualWidth <= 0 ||
                listBoxItem.ActualHeight <= 0 ||
                !IsScreenPointOverElement(listBoxItem, screenPoint))
            {
                continue;
            }

            tabStripItem = targetItem;
            return true;
        }

        return false;
    }

    private bool HasPotentialPictureInPictureDropTarget(IReadOnlyCollection<StreamTabViewModel> draggedTabs) => pictureInPicture.HasPotentialPictureInPictureDropTarget(draggedTabs);

    private bool HasExceededTabDetachDragDistance(NativePoint screenPoint)
    {
        return HasExceededDragDistance(tabDetachDragStartScreenPoint, screenPoint);
    }

    private static bool HasExceededDragDistance(NativePoint startPoint, NativePoint screenPoint)
    {
        return Math.Abs(screenPoint.X - startPoint.X) >= GetSystemMetrics(SmCxDrag) ||
            Math.Abs(screenPoint.Y - startPoint.Y) >= GetSystemMetrics(SmCyDrag);
    }

    private bool IsScreenPointOutsideTabStrip(NativePoint screenPoint)
    {
        if (!TabListBox.IsVisible || TabListBox.ActualWidth <= 0 || TabListBox.ActualHeight <= 0)
        {
            return false;
        }

        var topLeft = TabListBox.PointToScreen(new Point(0, 0));
        var bottomRight = TabListBox.PointToScreen(new Point(TabListBox.ActualWidth, TabListBox.ActualHeight));
        var transformToDevice = PresentationSource.FromVisual(TabListBox)?.CompositionTarget?.TransformToDevice ?? Matrix.Identity;
        var marginX = TabDetachOuterMargin * transformToDevice.M11;
        var marginY = TabDetachOuterMargin * transformToDevice.M22;
        var left = Math.Min(topLeft.X, bottomRight.X) - marginX;
        var right = Math.Max(topLeft.X, bottomRight.X) + marginX;
        var top = Math.Min(topLeft.Y, bottomRight.Y) - marginY;
        var bottom = Math.Max(topLeft.Y, bottomRight.Y) + marginY;

        return screenPoint.X < left ||
            screenPoint.X > right ||
            screenPoint.Y < top ||
            screenPoint.Y > bottom;
    }

    private NativePoint PointToNativeScreenPoint(Point windowPoint)
    {
        var screenPoint = PointToScreen(windowPoint);
        return new NativePoint((int)Math.Round(screenPoint.X), (int)Math.Round(screenPoint.Y));
    }

    private NativePoint ClientMessagePointToNativeScreenPoint(IntPtr lParam)
    {
        var value = lParam.ToInt32();
        var clientX = (short)(value & 0xFFFF);
        var clientY = (short)((value >> 16) & 0xFFFF);
        var hwnd = windowHandle != IntPtr.Zero
            ? windowHandle
            : new WindowInteropHelper(this).Handle;
        var point = new WindowPoint
        {
            X = clientX,
            Y = clientY
        };
        return hwnd != IntPtr.Zero && ClientToScreen(hwnd, ref point)
            ? new NativePoint(point.X, point.Y)
            : PointToNativeScreenPoint(new Point(clientX, clientY));
    }

    private static bool IsLeftMouseButtonPressed()
    {
        return IsAsyncKeyPressed(VkLeftButton);
    }

    private static bool IsControlModifierPressed()
    {
        return Keyboard.Modifiers.HasFlag(ModifierKeys.Control) ||
            IsAsyncKeyPressed(VkControl) ||
            IsAsyncKeyPressed(VkLeftControl) ||
            IsAsyncKeyPressed(VkRightControl);
    }

    private static bool IsAsyncKeyPressed(int virtualKey)
    {
        return (GetAsyncKeyState(virtualKey) & 0x8000) != 0;
    }

    private static NativePoint? GetCursorScreenPoint()
    {
        return GetCursorPos(out var point)
            ? new NativePoint(point.X, point.Y)
            : null;
    }

    internal void DetachTabToPictureInPicture(StreamTabViewModel tab, Point screenPoint, bool continueDrag) => pictureInPicture.DetachTabToPictureInPicture(tab, screenPoint, continueDrag);

    internal bool PositionDetachedWindow(DetachedVideoWindow window, Point screenPoint, bool useSavedLocation) => pictureInPicture.PositionDetachedWindow(window, screenPoint, useSavedLocation);

    internal Task RememberPictureInPictureWindowBoundsAsync(DetachedVideoWindow window) => pictureInPicture.RememberPictureInPictureWindowBoundsAsync(window);

    internal void ViewModelTabsCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => pictureInPicture.ViewModelTabsCollectionChanged(sender, e);

    private void CloseAllDetachedWindows(bool reattach) => pictureInPicture.CloseAllDetachedWindows(reattach);

    private void MuteButton_Click(object sender, RoutedEventArgs e)
    {
        if (viewModel?.SelectedTab is not null)
        {
            viewModel.SelectedTab.IsMuted = !viewModel.SelectedTab.IsMuted;
        }
    }

    private void VideoSurface_MouseWheelScrolled(object sender, VideoSurfaceMouseWheelEventArgs e)
    {
        if (sender is not FrameworkElement { Tag: StreamTabViewModel tab } || e.Delta == 0)
        {
            return;
        }

        if (e.ScreenPoint is { } point)
        {
            var screenPoint = new NativePoint((int)point.X, (int)point.Y);
            if (!IsScreenPointOverVideoContent(tab, screenPoint) ||
                TryRouteNativeOverlayWheel(tab, screenPoint, e.Delta))
            {
                return;
            }
        }

        AdjustVolume(tab, e.Delta);
    }

    private void VideoSurface_MouseLeftButtonDoubleClicked(object? sender, EventArgs e)
    {
        if (sender is FrameworkElement { Tag: StreamTabViewModel tab } && viewModel is not null)
        {
            viewModel.SelectedTab = tab;
        }

        ToggleStreamFullscreenFromVideoDoubleClick();
    }

    private void VideoViewport_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (ReplaySeekOverlay.IsReplayOverlayInput(e.OriginalSource))
        {
            return;
        }

        if (e.ClickCount == 2 && ToggleStreamFullscreenFromVideoDoubleClick())
        {
            e.Handled = true;
            return;
        }

        if (e.ChangedButton == MouseButton.Left)
        {
            _ = BeginVideoReorderDragCandidate(PointToNativeScreenPoint(e.GetPosition(this)));
        }
    }

    private void DockedChatPanel_PreviewMouseWheel(object sender, MouseWheelEventArgs e) => dockedChatController.DockedChatPanel_PreviewMouseWheel(sender, e);

    internal void DockedChatResizeThumb_DragDelta(object sender, DragDeltaEventArgs e) => dockedChatController.DockedChatResizeThumb_DragDelta(sender, e);

    private void ChatListBox_PreviewMouseWheel(object sender, MouseWheelEventArgs e) => dockedChatController.ChatListBox_PreviewMouseWheel(sender, e);

    private void DockedChatScrollThumb_DragStarted(object sender, DragStartedEventArgs e) => dockedChatController.DockedChatScrollThumb_DragStarted(sender, e);

    private void DockedChatScrollThumb_DragCompleted(object sender, DragCompletedEventArgs e) => dockedChatController.DockedChatScrollThumb_DragCompleted(sender, e);

    private void EnsureDockedChatScrollViewer() => dockedChatController.EnsureDockedChatScrollViewer();

    private void DockedChatItemsOnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => dockedChatController.DockedChatItemsOnCollectionChanged(sender, e);

    private void LockDockedChatToBottom() => dockedChatController.LockDockedChatToBottom();

    private void QueueDockedChatScrollToBottom(bool force) => dockedChatController.QueueDockedChatScrollToBottom(force);

    private void TabListBox_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (e.Delta == 0)
        {
            return;
        }

        ScrollTabs(e.Delta);
        e.Handled = true;
    }

    internal bool TryRouteMouseWheel(int screenX, int screenY, int delta)
    {
        return TryRouteMouseWheel(new NativePoint(screenX, screenY), delta);
    }

    private bool TryRouteMouseWheel(NativePoint screenPoint, int delta)
    {
        if (delta == 0 || !IsActive || windowHandle == IntPtr.Zero || GetForegroundWindow() != windowHandle)
        {
            return false;
        }

        if (IsScreenPointOverElement(TabListBox, screenPoint))
        {
            ScrollTabs(delta);
            return true;
        }

        if (IsScreenPointOverElement(DockedChatListBox, screenPoint))
        {
            ScrollDockedChat(delta);
            return true;
        }

        var videoTab = GetVideoTabAtScreenPoint(screenPoint);
        if (videoTab is not null && TryRouteNativeOverlayWheel(videoTab, screenPoint, delta))
        {
            return true;
        }

        if (videoTab is not null && IsScreenPointOverVideoContent(videoTab, screenPoint))
        {
            AdjustVolume(videoTab, delta);
            return true;
        }

        return false;
    }

    private bool TryRouteDetachedMouseWheel(NativePoint screenPoint, int delta) => pictureInPicture.TryRouteDetachedMouseWheel(screenPoint, delta);

    private bool TryBeginDetachedResizeFromScreenClick(NativePoint screenPoint) => pictureInPicture.TryBeginDetachedResizeFromScreenClick(screenPoint);

    private bool TryBeginDetachedVideoMoveFromScreenClick(NativePoint screenPoint) => pictureInPicture.TryBeginDetachedVideoMoveFromScreenClick(screenPoint);

    private bool TryContinueDetachedVideoMove(NativePoint screenPoint) => pictureInPicture.TryContinueDetachedVideoMove(screenPoint);

    private void CancelDetachedVideoMoveCandidates() => pictureInPicture.CancelDetachedVideoMoveCandidates();

    private bool TryOpenDetachedVideoContextMenu(NativePoint screenPoint) => pictureInPicture.TryOpenDetachedVideoContextMenu(screenPoint);

    private bool TryRouteNativeOverlayWheel(StreamTabViewModel tab, NativePoint screenPoint, int delta)
    {
        if (viewModel?.Settings.Chat.Layout != ChatLayout.Overlay ||
            !tab.IsChatVisible ||
            !tab.UsesNativeOverlay)
        {
            return false;
        }

        if (!IsScreenPointOverElement(VideoViewport, screenPoint) ||
            !TryGetVideoWheelPoint(tab, screenPoint, out var videoPoint, out var videoWidth, out var videoHeight) ||
            !IsVideoPointInside(videoPoint, videoWidth, videoHeight) ||
            !TryGetNativeOverlayBounds(tab, videoHeight, out var overlayBounds) ||
            !overlayBounds.Contains(videoPoint))
        {
            return false;
        }

        var localPoint = new Point(videoPoint.X - overlayBounds.Left, videoPoint.Y - overlayBounds.Top);
        if (IsNativeOverlayScrollableMessagePoint(localPoint, overlayBounds.Width, overlayBounds.Height, videoHeight))
        {
            SendNativeOverlayScroll(tab, delta);
        }

        return true;
    }

    private void ScrollDockedChat(int delta) => dockedChatController.ScrollDockedChat(delta);

    private void ScrollTabs(int delta)
    {
        var scrollViewer = FindVisualChild<ScrollViewer>(TabListBox);
        if (scrollViewer is null)
        {
            return;
        }

        var notches = delta / (double)Mouse.MouseWheelDeltaForOneLine;
        var targetOffset = Math.Clamp(
            scrollViewer.HorizontalOffset - notches * TabPixelsPerWheelNotch,
            0,
            scrollViewer.ScrollableWidth);

        scrollViewer.ScrollToHorizontalOffset(targetOffset);
    }

    private void AdjustVolume(StreamTabViewModel tab, int delta)
    {
        VolumeOverlay.AdjustVolume(tab, delta, VolumeOsd, ResolveVolumeOsdTarget(tab));
    }

    private UIElement ResolveVolumeOsdTarget(StreamTabViewModel tab)
    {
        return videoSurfaces.TryGetValue(tab, out var surface) && surface.IsVisible
            ? surface
            : VideoViewport;
    }

    private StreamTabViewModel? GetVideoTabAtScreenPoint(NativePoint screenPoint)
    {
        if (ReplaySeekOverlay.IsReplayOverlayWindow(windowHitTester.WindowFromPoint(screenPoint.X, screenPoint.Y)))
        {
            return null;
        }

        foreach (var (tab, surface) in videoSurfaces)
        {
            if (tab.IsVideoVisible && IsScreenPointOverElement(surface, screenPoint))
            {
                return tab;
            }
        }

        return null;
    }

    private bool IsScreenPointOverVideoContent(StreamTabViewModel tab, NativePoint screenPoint)
    {
        // VideoSurfaceGridPanel already fits this HWND to the video's aspect ratio.
        // Input must not depend on VLC's native lock or its last sampled cursor.
        return videoSurfaces.TryGetValue(tab, out var surface) &&
            IsScreenPointOverElement(surface, screenPoint);
    }

    private bool TryGetNativeOverlayBounds(StreamTabViewModel tab, int videoHeight, out VideoRect bounds)
    {
        bounds = default;
        if (viewModel is null)
        {
            return false;
        }

        var x = DefaultOverlayChatX;
        var y = DefaultOverlayChatY;
        var hidden = false;
        if (!string.IsNullOrWhiteSpace(tab.NativeOverlayPositionStatePath) &&
            TryReadIntFile(tab.NativeOverlayPositionStatePath, out var positionValues))
        {
            if (positionValues.Length >= 2)
            {
                x = positionValues[0];
                y = positionValues[1];
            }

            if (positionValues.Length >= 3)
            {
                hidden = positionValues[2] != 0;
            }
        }

        if (hidden)
        {
            return false;
        }

        var referenceWidth = NativeOverlaySizing.ClampReferenceWidth((int)Math.Round(viewModel.Settings.Chat.DockWidth));
        var referenceHeight = DefaultOverlayChatHeight;
        var width = ScaleOverlayReferencePixels(videoHeight, referenceWidth);
        var height = ScaleOverlayReferencePixels(videoHeight, referenceHeight);
        var sizePath = string.IsNullOrWhiteSpace(tab.NativeOverlayPositionStatePath)
            ? null
            : $"{tab.NativeOverlayPositionStatePath}.size";
        if (!string.IsNullOrWhiteSpace(sizePath) &&
            NativeOverlaySizing.TryReadSizeFile(sizePath, out var sizeWidth, out var sizeHeight, out var referenceSize))
        {
            if (referenceSize)
            {
                width = ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.ClampReferenceWidth(sizeWidth));
                height = ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.ClampReferenceHeight(sizeHeight));
            }
            else
            {
                width = Math.Clamp(
                    sizeWidth,
                    ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.MinWidth),
                    ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.MaxWidth));
                height = Math.Clamp(
                    sizeHeight,
                    ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.MinHeight),
                    ScaleOverlayReferencePixels(videoHeight, NativeOverlaySizing.MaxHeight));
            }
        }

        bounds = new VideoRect(x, y, width, height);
        return true;
    }

    private static bool TryGetVideoCursorPoint(
        StreamTabViewModel tab,
        out Point videoPoint,
        out int videoWidth,
        out int videoHeight)
    {
        videoPoint = default;
        videoWidth = 0;
        videoHeight = 0;
        if (!tab.TryGetVideoSize(out videoWidth, out videoHeight) ||
            !tab.TryGetVideoCursor(out var x, out var y))
        {
            return false;
        }

        videoPoint = new Point(x, y);
        return true;
    }

    private bool TryGetVideoWheelPoint(
        StreamTabViewModel tab,
        NativePoint screenPoint,
        out Point videoPoint,
        out int videoWidth,
        out int videoHeight)
    {
        videoPoint = default;
        videoWidth = 0;
        videoHeight = 0;
        if (!videoSurfaces.TryGetValue(tab, out var surface) ||
            !IsScreenPointOverElement(surface, screenPoint) ||
            surface.ActualWidth <= 0 || surface.ActualHeight <= 0 ||
            (!tab.TryGetLastVideoSize(out videoWidth, out videoHeight) &&
             !tab.TryGetVideoSize(out videoWidth, out videoHeight)))
        {
            return false;
        }

        // Use the wheel event's position even if the pointer moved while WPF was busy.
        // Dimensions are retained by the existing video-size poller; VLC's native
        // audio/video lock cannot make a known chat overlay disappear during input.
        var local = surface.PointFromScreen(new Point(screenPoint.X, screenPoint.Y));
        videoPoint = new Point(
            local.X * videoWidth / surface.ActualWidth,
            local.Y * videoHeight / surface.ActualHeight);
        return true;
    }

    private static bool IsVideoPointInside(Point videoPoint, int videoWidth, int videoHeight)
    {
        return videoWidth > 0 &&
            videoHeight > 0 &&
            videoPoint.X >= 0 &&
            videoPoint.X < videoWidth &&
            videoPoint.Y >= 0 &&
            videoPoint.Y < videoHeight;
    }

    private static bool IsNativeOverlayScrollableMessagePoint(Point localPoint, int overlayWidth, int overlayHeight, int videoHeight)
    {
        var messagePadding = ScaleOverlayReferencePixels(videoHeight, OverlayMessagePadding);
        var chatInputHeight = ScaleOverlayReferencePixels(videoHeight, OverlayChatInputHeight);
        var chatInputGap = ScaleOverlayReferencePixels(videoHeight, OverlayChatInputGap);
        var buttonMargin = ScaleOverlayReferencePixels(videoHeight, OverlayButtonMargin);
        var hideButtonWidth = ScaleOverlayReferencePixels(videoHeight, OverlayHideButtonWidth);
        var hideButtonHeight = ScaleOverlayReferencePixels(videoHeight, OverlayHideButtonHeight);
        var hitInset = ScaleOverlayReferencePixels(videoHeight, (int)Math.Round(OverlayChatHitInsetPixels));

        var messageLeft = messagePadding + hitInset;
        var messageTop = messagePadding + hitInset;
        var messageRight = overlayWidth - messagePadding - hitInset;
        var messageBottom = overlayHeight - messagePadding - chatInputHeight - chatInputGap - hitInset;
        if (messageBottom <= messageTop || messageRight <= messageLeft)
        {
            return false;
        }

        if (localPoint.X < messageLeft ||
            localPoint.X >= messageRight ||
            localPoint.Y < messageTop ||
            localPoint.Y >= messageBottom)
        {
            return false;
        }

        var buttonLeft = overlayWidth - hideButtonWidth - buttonMargin;
        var buttonRight = buttonLeft + hideButtonWidth;
        var buttonTop = buttonMargin;
        var buttonBottom = buttonTop + hideButtonHeight;

        return localPoint.X < buttonLeft ||
            localPoint.X >= buttonRight ||
            localPoint.Y < buttonTop ||
            localPoint.Y >= buttonBottom;
    }

    private static int ScaleOverlayReferencePixels(int videoHeight, int value)
    {
        return NativeOverlaySizing.ScaleReferencePixels(videoHeight, value);
    }

    private static bool TryReadIntFile(string path, out int[] values)
    {
        values = [];
        try
        {
            if (!File.Exists(path))
            {
                return false;
            }

            values = NativeOverlaySizing.ParseInts(File.ReadAllText(path));
            return values.Length > 0;
        }
        catch (IOException)
        {
            return false;
        }
        catch (UnauthorizedAccessException)
        {
            return false;
        }
    }

    private static void SendNativeOverlayScroll(StreamTabViewModel tab, int delta)
    {
        if (string.IsNullOrWhiteSpace(tab.NativeOverlayPipeName))
        {
            return;
        }

        var notches = Math.Sign(delta) * Math.Max(1, Math.Abs(delta) / Mouse.MouseWheelDeltaForOneLine);
        try
        {
            using var pipe = new NamedPipeClientStream(".", $"{tab.NativeOverlayPipeName}_events", PipeDirection.Out);
            pipe.Connect(10);

            var buffer = NativeOverlayProtocolCodec.BuildEventMessage(
                NativeOverlayProtocolCodec.ScrollEventType,
                notches);
            pipe.Write(buffer);
        }
        catch (Exception ex) when (ex is IOException or TimeoutException or UnauthorizedAccessException)
        {
        }
    }

    private static bool IsScreenPointOverElement(FrameworkElement element, NativePoint screenPoint)
    {
        return WindowInteropHelpers.IsScreenPointOverElement(element, screenPoint.X, screenPoint.Y);
    }

    private static bool IsPointOverElement(FrameworkElement element, Point point)
    {
        return element.IsVisible &&
            element.ActualWidth > 0 &&
            element.ActualHeight > 0 &&
            point.X >= 0 &&
            point.X < element.ActualWidth &&
            point.Y >= 0 &&
            point.Y < element.ActualHeight;
    }

    private Rect GetCurrentMonitorBounds(bool useWorkingArea)
    {
        var hwnd = windowHandle != IntPtr.Zero
            ? windowHandle
            : new WindowInteropHelper(this).Handle;

        if (!TryGetMonitorInfo(hwnd, out var monitorInfo))
        {
            return useWorkingArea
                ? SystemParameters.WorkArea
                : new Rect(0, 0, SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight);
        }

        return this.ToDeviceIndependentRect(useWorkingArea ? monitorInfo.WorkArea : monitorInfo.Monitor);
    }

    private Rect GetMonitorWorkingAreaAtScreenPoint(Point screenPoint)
    {
        var nativePoint = new NativePoint(
            (int)Math.Round(screenPoint.X),
            (int)Math.Round(screenPoint.Y));
        var monitor = MonitorFromPoint(nativePoint, MonitorDefaultToNearest);
        if (monitor == IntPtr.Zero)
        {
            return SystemParameters.WorkArea;
        }

        return TryGetMonitorInfoForMonitor(monitor, out var monitorInfo)
            ? this.ToDeviceIndependentRect(monitorInfo.WorkArea)
            : SystemParameters.WorkArea;
    }

    private Rect GetMonitorWorkingAreaAtDeviceIndependentPoint(Point point)
    {
        return GetMonitorWorkingAreaAtScreenPoint(this.ToDevicePoint(point));
    }

    private Rect GetRestorableWindowBounds()
    {
        if (WindowState == WindowState.Normal)
        {
            return new Rect(Left, Top, Width, Height);
        }

        return IsUsableWindowBounds(RestoreBounds)
            ? RestoreBounds
            : new Rect(Left, Top, Width, Height);
    }

    private void ApplyWindowBounds(Rect bounds)
    {
        if (!IsUsableWindowBounds(bounds))
        {
            return;
        }

        Left = bounds.Left;
        Top = bounds.Top;
        Width = bounds.Width;
        Height = bounds.Height;
    }

    private void InstallMouseWheelHook()
    {
        if (mouseHookPump is not null)
        {
            return;
        }

        try
        {
            var hookDispatcher = new LowLevelMouseHookDispatcher(
                Dispatcher,
                RouteLowLevelMouseHookEvent,
                HasActiveLowLevelMouseMoveRoute);
            mouseHookPump = new LowLevelMouseHookPump(hookDispatcher, () => appLogger);
            mouseHookPump.Start();
        }
        catch (Exception)
        {
            mouseHookPump?.Dispose();
            mouseHookPump = null;
        }
    }

    private void UninstallMouseWheelHook()
    {
        mouseHookPump?.Dispose();
        mouseHookPump = null;
    }

    internal bool HasActiveLowLevelMouseMoveRoute()
    {
        return hasActiveLowLevelMouseMoveRoute;
    }

    internal bool RouteLowLevelMouseHookEvent(LowLevelMouseHookEvent hookEvent)
    {
        var screenPoint = new NativePoint(hookEvent.ScreenX, hookEvent.ScreenY);
        if (hookEvent.Message == LowLevelMouseHookEvent.WmMouseWheel)
        {
            var delta = hookEvent.WheelDelta;
            return TryRouteDetachedMouseWheel(screenPoint, delta) ||
                TryRouteMouseWheel(screenPoint, delta);
        }

        if (hookEvent.Message == LowLevelMouseHookEvent.WmMouseMove)
        {
            _ = TryContinueDetachedVideoMove(screenPoint);

            if (videoReorderDragTab is not null)
            {
                _ = TryContinueVideoReorderDrag(screenPoint);
            }

            if (tabDetachDragTab is not null &&
                !IsScreenPointInMainWindow(screenPoint))
            {
                _ = TryContinueTabDetachDrag(screenPoint, continueDrag: true);
            }

            return false;
        }

        if (hookEvent.Message == LowLevelMouseHookEvent.WmLeftButtonDown)
        {
            if (TryBeginDetachedResizeFromScreenClick(screenPoint))
            {
                return true;
            }

            if (TryToggleDetachedStreamFullscreenFromVideoDoubleClick(screenPoint))
            {
                return true;
            }

            _ = TryActivateDetachedVideoTabFromScreenClick(screenPoint);
            _ = TryBeginDetachedVideoMoveFromScreenClick(screenPoint);

            if (TryToggleStreamFullscreenFromVideoDoubleClick(screenPoint))
            {
                return true;
            }

            _ = TryActivateVideoTabFromScreenClick(screenPoint);
            _ = BeginVideoReorderDragCandidate(screenPoint);

            return false;
        }

        if (hookEvent.Message == LowLevelMouseHookEvent.WmLeftButtonUp)
        {
            CancelDetachedVideoMoveCandidates();

            if (!TryCompleteVideoReorderDrag(screenPoint))
            {
                ClearVideoReorderDrag();
            }

            if (!IsScreenPointInMainWindow(screenPoint))
            {
                _ = TryCompleteTabDetachDrag(screenPoint);
                ClearTabDetachDrag();
            }
        }

        if (hookEvent.Message == LowLevelMouseHookEvent.WmRightButtonDown)
        {
            return TryOpenDetachedVideoContextMenu(screenPoint);
        }

        return false;
    }

    private static T? FindVisualChild<T>(DependencyObject parent)
        where T : DependencyObject
    {
        for (var index = 0; index < VisualTreeHelper.GetChildrenCount(parent); index++)
        {
            var child = VisualTreeHelper.GetChild(parent, index);
            if (child is T match)
            {
                return match;
            }

            var descendant = FindVisualChild<T>(child);
            if (descendant is not null)
            {
                return descendant;
            }
        }

        return null;
    }

    private static T? FindVisualParent<T>(DependencyObject child)
        where T : DependencyObject
    {
        var parent = VisualTreeHelper.GetParent(child);
        while (parent is not null)
        {
            if (parent is T match)
            {
                return match;
            }

            parent = VisualTreeHelper.GetParent(parent);
        }

        return null;
    }

    private void FullscreenButton_Click(object sender, RoutedEventArgs e) => windowMode.FullscreenButton_Click(sender, e);

    private void TheatreButton_Click(object sender, RoutedEventArgs e) => windowMode.TheatreButton_Click(sender, e);

    internal FullscreenMode GetFullscreenButtonMode() => windowMode.GetFullscreenButtonMode();

    internal void ToggleFullscreenMode(FullscreenMode requestedMode) => windowMode.ToggleFullscreenMode(requestedMode);

    private void ApplyFullscreenSelectedTabState() => windowMode.ApplyFullscreenSelectedTabState();

    internal void ApplyTheatreModeChatToSelectedTab() => windowMode.ApplyTheatreModeChatToSelectedTab();

    internal void ExitFullscreenMode() => windowMode.ExitFullscreenMode();

    private void MarkTaskbarFullscreen(bool force = false) => windowMode.MarkTaskbarFullscreen(force);

    private bool ShouldMarkTaskbarFullscreen() => windowMode.ShouldMarkTaskbarFullscreen();

    private void ClearTaskbarFullscreen() => windowMode.ClearTaskbarFullscreen();

    internal bool ToggleStreamFullscreenFromVideoDoubleClick() => windowMode.ToggleStreamFullscreenFromVideoDoubleClick();

    internal bool TryToggleDetachedStreamFullscreenFromVideoDoubleClick(NativePoint screenPoint) => pictureInPicture.TryToggleDetachedStreamFullscreenFromVideoDoubleClick(screenPoint);

    private bool TryActivateDetachedVideoTabFromScreenClick(NativePoint screenPoint) => pictureInPicture.TryActivateDetachedVideoTabFromScreenClick(screenPoint);

    internal bool TryActivateVideoTabFromScreenClick(int screenX, int screenY)
    {
        return TryActivateVideoTabFromScreenClick(new NativePoint(screenX, screenY));
    }

    private bool TryActivateVideoTabFromScreenClick(NativePoint screenPoint)
    {
        if (viewModel is null ||
            !IsScreenPointInMainWindow(screenPoint) ||
            GetVideoTabAtScreenPoint(screenPoint) is not { } tab ||
            !viewModel.Tabs.Contains(tab))
        {
            return false;
        }

        viewModel.SelectedTab = tab;
        return true;
    }

    private bool TryToggleStreamFullscreenFromVideoDoubleClick(NativePoint screenPoint)
    {
        if (!IsScreenPointInMainWindow(screenPoint) ||
            viewModel is null ||
            GetVideoTabAtScreenPoint(screenPoint) is not { } tab)
        {
            ResetVideoDoubleClickTracking();
            return false;
        }

        var now = Environment.TickCount64;
        var isDoubleClick = IsTrackedVideoDoubleClick(now, screenPoint);
        CaptureVideoLeftButtonDown(now, screenPoint);

        if (!isDoubleClick)
        {
            return false;
        }

        ResetVideoDoubleClickTracking();
        viewModel.SelectedTab = tab;
        if (fullscreen)
        {
            ExitFullscreenMode();
        }
        else
        {
            ToggleFullscreenMode(FullscreenMode.StreamOnly);
        }

        return true;
    }

    private bool IsTrackedVideoDoubleClick(long now, NativePoint screenPoint) =>
        videoDoubleClickTracker.IsDoubleClick(now, screenPoint.X, screenPoint.Y);

    private void CaptureVideoLeftButtonDown(long now, NativePoint screenPoint) =>
        videoDoubleClickTracker.Capture(now, screenPoint.X, screenPoint.Y);

    private void ResetVideoDoubleClickTracking() => videoDoubleClickTracker.Reset();

    private bool IsScreenPointInMainWindow(NativePoint screenPoint)
    {
        if (windowHandle == IntPtr.Zero)
        {
            return false;
        }

        return WindowHitTestPolicy.IsPointInWindow(
            windowHitTester,
            windowHandle,
            screenPoint.X,
            screenPoint.Y,
            includeOwnedPopups: false);
    }

    private void ApplyWindowChromeHitTestState() => windowMode.ApplyWindowChromeHitTestState();

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        WindowState = WindowState.Minimized;
    }

    private void MaximizeRestoreButton_Click(object sender, RoutedEventArgs e)
    {
        ToggleMaximizeRestore();
    }

    private void CloseWindowButton_Click(object sender, RoutedEventArgs e)
    {
        viewModel?.CloseAllTabs();
        Close();
    }

    private void InitializeTrayIcon() => windowMode.InitializeTrayIcon();

    private void HandleTrayIconMessage(IntPtr lParam) => windowMode.HandleTrayIconMessage(lParam);

    private void HideToTray() => windowMode.HideToTray();

    private void ShowMainWindow() => windowMode.ShowMainWindow();

    private void RequestApplicationExit() => windowMode.RequestApplicationExit();

    private void DisposeTrayIcon() => windowMode.DisposeTrayIcon();

    private void ToggleMaximizeRestore() => windowMode.ToggleMaximizeRestore();

    private void UpdateMaximizeRestoreButton() => windowMode.UpdateMaximizeRestoreButton();

    private void ChatInputTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
        {
            return;
        }

        var command = viewModel?.SelectedTab?.SendChatMessageCommand;
        if (command?.CanExecute(null) == true)
        {
            command.Execute(null);
        }

        e.Handled = true;
    }

    private void StreamSearchTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
        {
            return;
        }

        var command = viewModel?.AddAndPlayCommand;
        if (command?.CanExecute(null) == true)
        {
            command.Execute(null);
        }

        e.Handled = true;
    }

    private void HomeSearchAnchor_PreviewMouseDown(object sender, MouseButtonEventArgs e)
    {
        Dispatcher.BeginInvoke(
            () => viewModel?.ShowStreamSearchDropdown(),
            DispatcherPriority.Input);
    }

    private void HomeStreamSearchTextBox_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
    {
        viewModel?.ShowStreamSearchDropdown();
    }

    private static bool IsPointInsideElement(FrameworkElement element, Point point)
    {
        return point.X >= 0 &&
            point.Y >= 0 &&
            point.X <= element.ActualWidth &&
            point.Y <= element.ActualHeight;
    }

    private void BrowseStreamlinkButton_Click(object sender, RoutedEventArgs e)
    {
        if (viewModel is null)
        {
            return;
        }

        var dialog = new OpenFileDialog
        {
            Title = "Select streamlink.exe",
            Filter = "Streamlink executable|streamlink.exe|Executable files|*.exe|All files|*.*",
            FileName = "streamlink.exe"
        };

        if (!string.IsNullOrWhiteSpace(viewModel.Settings.StreamlinkPath))
        {
            dialog.InitialDirectory = Path.GetDirectoryName(viewModel.Settings.StreamlinkPath);
        }

        if (dialog.ShowDialog(this) == true)
        {
            viewModel.Settings.StreamlinkPath = dialog.FileName;
            viewModel.RefreshSettingsBindings();
        }
    }

    private void BrowseVlcButton_Click(object sender, RoutedEventArgs e)
    {
        if (viewModel is null)
        {
            return;
        }

        var dialog = new OpenFileDialog
        {
            Title = "Select libvlc.dll",
            Filter = "libVLC|libvlc.dll|Dynamic libraries|*.dll|All files|*.*",
            FileName = "libvlc.dll"
        };

        if (!string.IsNullOrWhiteSpace(viewModel.Settings.VlcDirectory))
        {
            dialog.InitialDirectory = viewModel.Settings.VlcDirectory;
        }

        if (dialog.ShowDialog(this) == true)
        {
            viewModel.Settings.VlcDirectory = Path.GetDirectoryName(dialog.FileName);
            viewModel.RefreshSettingsBindings();
        }
    }

    [StructLayout(LayoutKind.Sequential)]
    internal readonly struct NativePoint
    {
        public NativePoint(int x, int y)
        {
            X = x;
            Y = y;
        }

        public readonly int X;
        public readonly int Y;
    }

    internal readonly struct TabStripItemBounds
    {
        public TabStripItemBounds(TabStripItemViewModel item, double left, double right, double top, double bottom)
        {
            Item = item;
            Left = left;
            Right = right;
            Top = top;
            Bottom = bottom;
        }

        public readonly TabStripItemViewModel Item;
        public readonly double Left;
        public readonly double Right;
        public readonly double Top;
        public readonly double Bottom;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    internal struct NotifyIconData
    {
        public int Size;
        public IntPtr WindowHandle;
        public uint Id;
        public uint Flags;
        public int CallbackMessage;
        public IntPtr IconHandle;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public string Tip;
        public uint State;
        public uint StateMask;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string Info;
        public uint TimeoutOrVersion;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string InfoTitle;
        public uint InfoFlags;
        public Guid Guid;
        public IntPtr BalloonIconHandle;
    }

    internal readonly struct VideoRect
    {
        public VideoRect(int left, int top, int width, int height)
        {
            Left = left;
            Top = top;
            Width = width;
            Height = height;
            Right = left + width;
            Bottom = top + height;
        }

        public int Left { get; }
        public int Top { get; }
        public int Width { get; }
        public int Height { get; }
        public int Right { get; }
        public int Bottom { get; }

        public bool Contains(Point point)
        {
            return point.X >= Left &&
                point.X < Right &&
                point.Y >= Top &&
                point.Y < Bottom;
        }
    }

    [LibraryImport("user32")]
    private static partial IntPtr GetForegroundWindow();

    [LibraryImport("user32", EntryPoint = "RegisterWindowMessageW", StringMarshalling = StringMarshalling.Utf16)]
    private static partial int RegisterWindowMessage(string message);

    [LibraryImport("user32")]
    private static partial int GetSystemMetrics(int nIndex);

    [LibraryImport("user32")]
    private static partial short GetAsyncKeyState(int vKey);

    [LibraryImport("user32")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool GetCursorPos(out WindowPoint point);

    [LibraryImport("user32")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool ClientToScreen(IntPtr hWnd, ref WindowPoint lpPoint);

    [LibraryImport("user32")]
    private static partial IntPtr MonitorFromPoint(NativePoint pt, uint dwFlags);

    [DllImport("shell32.dll", EntryPoint = "Shell_NotifyIconW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool Shell_NotifyIcon(int message, ref NotifyIconData data);

    [LibraryImport("shell32", EntryPoint = "ExtractIconExW", StringMarshalling = StringMarshalling.Utf16, SetLastError = true)]
    private static partial uint ExtractIconEx(string fileName, int iconIndex, out IntPtr largeIcon, out IntPtr smallIcon, uint icons);

    [LibraryImport("user32", EntryPoint = "LoadIconW", SetLastError = true)]
    private static partial IntPtr LoadIcon(IntPtr instance, IntPtr iconName);

    [LibraryImport("user32", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool DestroyIcon(IntPtr icon);

    [LibraryImport("user32", SetLastError = true)]
    private static partial IntPtr CreatePopupMenu();

    [DllImport("user32.dll", EntryPoint = "AppendMenuW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool AppendMenu(IntPtr menu, uint flags, UIntPtr newItemId, string? newItem);

    [LibraryImport("user32", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool DestroyMenu(IntPtr menu);

    [LibraryImport("user32", SetLastError = true)]
    private static partial int TrackPopupMenuEx(IntPtr menu, uint flags, int x, int y, IntPtr hwnd, IntPtr parameters);

    [LibraryImport("user32")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static partial bool SetForegroundWindow(IntPtr hwnd);

}
