using StreamlinkVlcStudio.Core.Models;
using StreamlinkVlcStudio.Core.Services;

namespace StreamlinkVlcStudio.Infrastructure.Vlc;

public sealed record LivePreviewFrame(int Width, int Height, byte[] Pixels);

/// <summary>A silent video-only player that never creates a native window or a playback tab.</summary>
public sealed class LibVlcLivePreview(IStreamlinkService streamlink)
{
    internal const int Width = 320;
    internal const int Height = 180;

    public async Task RunAsync(StreamTransportRequest request, string vlcDirectory,
        Action<LivePreviewFrame> present, CancellationToken token)
    {
        // The transport owns and kills its process tree, including canceled startup.
        using var startup = CancellationTokenSource.CreateLinkedTokenSource(token);
        startup.CancelAfter(TimeSpan.FromSeconds(20));
        await using var transport = await streamlink.StartExternalHttpAsync(request, startup.Token).ConfigureAwait(false);
        token.ThrowIfCancellationRequested();
        await DecodeAsync(transport.PlaybackUri, vlcDirectory, present, token).ConfigureAwait(false);
    }

    internal static async Task DecodeAsync(Uri uri, string vlcDirectory,
        Action<LivePreviewFrame> present, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        if (!File.Exists(Path.Combine(vlcDirectory, "libvlc.dll")))
            throw new FileNotFoundException("Configure the VLC installation directory to play previews.");

        // Previews can be the first playback in this process. Keep the existing plugin path.
        LibVlcNative.SetDllDirectory(vlcDirectory);
        using var runtime = LibVlcRuntime.Acquire(vlcDirectory, VideoRendererMode.Automatic,
            ["--intf=dummy", "--ignore-config", "--no-audio", "--no-spu", "--no-osd",
             "--no-video-title-show", "--no-stats", "--avcodec-hw=none", "--network-caching=500", "--quiet"], share: false);
        var lastFrameAt = Environment.TickCount64;
        long lastPresentation = 0;
        using var player = new LibVlcPreviewPlayer(runtime.Instance, uri, Width, Height, () =>
        {
            var now = Environment.TickCount64;
            Interlocked.Exchange(ref lastFrameAt, now);
            if (token.IsCancellationRequested || now - lastPresentation < 33) return false;
            lastPresentation = now;
            return true;
        }, pixels => present(new LivePreviewFrame(Width, Height, pixels)));
        if (!player.Start()) throw new InvalidOperationException("VLC could not play the preview.");
        while (true)
        {
            await Task.Delay(100, token).ConfigureAwait(false);
            if (player.CallbackFailure.IsCompleted) await player.CallbackFailure.ConfigureAwait(false);
            if (player.State is LibVlcNative.MediaPlayerState.Ended or LibVlcNative.MediaPlayerState.Error or LibVlcNative.MediaPlayerState.Stopped)
                throw new InvalidOperationException("The preview stream ended or is unavailable.");
            if (Environment.TickCount64 - Interlocked.Read(ref lastFrameAt) > 20_000)
                throw new TimeoutException("The preview stream stopped delivering video.");
        }
    }
}
