# Live stream hover previews

Enable **Settings > General > Appearance & behavior > Live stream previews on hover**.
The switch applies immediately; **Save changes** keeps it across restarts. Existing
settings default to off. Followed and Browse live cards, live search results, and
Recent rows confirmed live play muted video inside their thumbnail while hovered.
VODs, offline channels, and unknown Recent statuses do not start previews.

A 100 ms delay avoids opening streams while passing across cards. One shared
controller serializes previews, including transport cleanup. It requests
`360p,480p,best` through the existing Streamlink HTTP transport with the configured
custom arguments and low-latency preference. An isolated VLC player disables
audio and chat and presents 320 x 180 pixels at up to 30 frames per second.
A single pending-frame slot and a single queued UI update prevent a busy UI from
accumulating work. Frame/state notifications request WPF
rendering directly, so displaying decoded video does not wait for a polling timer.

The WPF image preserves card input, scrolling, clipping, and badges. Leaving,
clicking, disabling previews, hiding/unloading the card, deactivating/minimizing
the window, or shutting down cancels playback. Replacement waits for the previous
player and transport to finish cleanup. Failed startup, unavailable media, and
stalled video restore the still thumbnail with a short unavailable label.

VLC callbacks follow the [VLC 3 media-player API](https://videolan.videolan.me/vlc-3.0/group__libvlc__media__player.html):
aligned frame memory, presentation at the playback clock, and native playback
stopped before delegates and memory are released. No preview tab, chat connection,
watch-history entry, or main-player audio change is created.

## Verification

- Release solution build with warnings treated as errors: zero warnings/errors.
- 15 focused checks cover persistence, disabled/offline states, debounce,
  transport options, canceled/late startup, stale frames, rapid replacement,
  failure recovery, missing VLC, bounded frames, shutdown, XAML bindings, and
  physical hover/click/leave/hide/disable/unload behavior.
- The physical hover check keeps input work pending while waiting for video. It
  failed with the original background timer and passes with frame notifications.
  A burst of 1,000 decoded frames queues at most one render and displays the latest
  frame after the UI resumes.
- The installed VLC decoded changing red-to-green fixture video and stopped
  producing frames after cancellation; the transport was disposed.
- Three physical hover trials per provider rendered changing Twitch and Kick video
  inside the production card and verified that disabling previews cleared it.
  Transport startup began 114–115 ms after hover, compared with 363–378 ms before
  the change. Observed first visible frames were 2.34–2.57 seconds; previous
  successful trials were 2.69–2.78 seconds, with additional stalled UI trials.
  Network/provider startup remains part of the wait.
- Each provider also played at least 12 seconds across segment boundaries. The
  largest frame gaps were 75–76 ms, and cancellation cleaned up in 35–39 ms.
- Complete headless suite: 1,211 passed, 247 desktop-only skips, zero failures.
  The focused interactive checks also ran separately with no skips.
- Self-contained Windows x64 single-file publish succeeded at
  `artifacts/hover-previews-fast/StreamStudio.exe`.

Run focused checks with the SDK selected by `global.json`:

```powershell
.\scripts\dev.ps1 Test -Filter 'stream hover preview:' -Interactive
```

The two additional live-provider checks opt in via `SVS_TEST_HOVER_CHANNEL`, set
to a currently live Twitch or Kick URL. They read existing transport settings but
do not save changes to them. Use a 75-second `SVS_TEST_TIMEOUT_SECONDS` for live
network tests. Live checks report transport readiness, first-frame timing, frame
gaps, and cleanup time without printing signed media URLs or authentication arguments.
Live-card PNGs are under `.tmp/hover-preview-*`; latency and regression logs are
under `.tmp/hover-preview-latency/`.
