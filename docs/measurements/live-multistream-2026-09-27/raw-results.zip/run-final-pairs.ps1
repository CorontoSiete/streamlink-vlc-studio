$ErrorActionPreference = 'Stop'
$urls = @('https://www.twitch.tv/eslcs', 'https://www.twitch.tv/valorant', 'https://kick.com/cuffem', 'https://kick.com/deenthegreat')
& 'scripts/measure-live-multistream.ps1' -BaselineTests (Join-Path $PSScriptRoot 'baseline-bin/StreamlinkVlcStudio.Tests.dll') -UpdatedTests (Join-Path $PSScriptRoot 'final-bin/StreamlinkVlcStudio.Tests.dll') -Urls $urls -OutputDirectory (Join-Path $PSScriptRoot 'final-matrix') -Trials 3 -WarmupSeconds 20 -Seconds 60
