$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/ComputerGuy/.dotnet'
$env:SVS_TEST_MULTISTREAM_LIVE_URLS = $null
$env:SVS_RESOURCE_BENCHMARK = $null
$env:SVS_TEST_TIMEOUT_SECONDS = '120'
& '.tools/pwsh/pwsh.exe' -NoProfile -File 'scripts/dev.ps1' Check *> (Join-Path $PSScriptRoot 'check.log')
if ($LASTEXITCODE -ne 0) { throw 'Full Check failed; inspect check.log.' }
Get-Content -LiteralPath (Join-Path $PSScriptRoot 'check.log') -Tail 5
$env:SVS_TEST_VLC_DIRECTORY = 'C:/Program Files/VideoLAN/VLC'
$env:SVS_TEST_VLC_MEDIA = [IO.Path]::GetFullPath('.tmp/multistream-resources/blue.mp4')
$env:SVS_TEST_ARTIFACT_DIR = Join-Path $PSScriptRoot 'ui-artifacts'
$groups = [ordered]@{
    'ui-resources' = 'multistream UI resources:'
    'docked-chat' = 'docked'
    'window-sharing' = 'window sharing'
    'responsive-vlc' = 'responsive main window keeps real'
    'replay-overlay' = 'replay seek overlay'
    'pip-resize' = 'picture-in-picture resize'
}
foreach ($group in $groups.GetEnumerator()) {
    $log = Join-Path $PSScriptRoot ('verify-' + $group.Key + '.log')
    Write-Output ('Checking ' + $group.Key)
    & '.tools/pwsh/pwsh.exe' -NoProfile -File 'scripts/dev.ps1' Test -Filter $group.Value -NoBuild -Interactive *> $log
    if ($LASTEXITCODE -ne 0) { throw "Interactive group $($group.Key) failed; inspect its full log." }
    Get-Content -LiteralPath $log -Tail 3
}
