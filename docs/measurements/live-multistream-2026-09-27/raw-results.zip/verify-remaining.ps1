$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/ComputerGuy/.dotnet'
$env:SVS_TEST_TIMEOUT_SECONDS = '120'
$env:SVS_TEST_MULTISTREAM_LIVE_URLS = $null
$env:SVS_RESOURCE_BENCHMARK = $null
$env:SVS_TEST_VLC_DIRECTORY = 'C:/Program Files/VideoLAN/VLC'
$env:SVS_TEST_VLC_MEDIA = [IO.Path]::GetFullPath('.tmp/multistream-resources/blue.mp4')
$env:SVS_TEST_ARTIFACT_DIR = Join-Path $PSScriptRoot 'ui-artifacts'
$groups = [ordered]@{
    'window-sharing' = 'window sharing'
    'responsive-vlc' = 'responsive main window keeps real'
    'replay-overlay' = 'replay seek overlay'
    'pip-resize' = 'picture-in-picture resize'
    'hidden-emotes' = 'resource usage hidden emotes'
}
foreach ($group in $groups.GetEnumerator()) {
    $log = Join-Path $PSScriptRoot ('verify-' + $group.Key + '.log')
    Write-Output ('Checking ' + $group.Key)
    & '.tools/pwsh/pwsh.exe' -NoProfile -File 'scripts/dev.ps1' Test -Filter $group.Value -NoBuild -Interactive *> $log
    if ($LASTEXITCODE -ne 0) { throw "Interactive group $($group.Key) failed; inspect its full log." }
    Get-Content -LiteralPath $log -Tail 3
}
Write-Output 'Checking two complete live open/play/chat/close cycles in one process.'
& '.tools/pwsh/pwsh.exe' -NoProfile -File (Join-Path $PSScriptRoot 'run-live.ps1') -Label 'updated-live-lifecycle' -BinaryDirectory ([IO.Path]::GetFullPath('tests/StreamlinkVlcStudio.Tests/bin/Release/net10.0-windows10.0.19041.0')) -Seconds 20 -Warmup 10 -Cycles 2
if ($LASTEXITCODE -ne 0) { throw 'Live lifecycle check failed; inspect its complete log.' }
