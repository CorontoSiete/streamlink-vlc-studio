import json
import statistics
import sys
from pathlib import Path

root = Path(sys.argv[1])
mib = 1024 ** 2
rows = []
for path in sorted(root.glob('*-*/results.json')):
    if path.parent.name.rsplit('-', 1)[-1] not in ('before', 'after'):
        continue
    for data in json.loads(path.read_text(encoding='utf-8-sig')):
        samples = data['samples']
        elapsed = data['measuredSeconds']
        before = {p['Pid']: p for p in data['beforeProcesses']}
        row = {
            'trial': path.parent.name,
            'version': path.parent.name.rsplit('-', 1)[-1],
            'utc': data['utc'],
            'seconds': elapsed,
            'cpuCores': data['cpuCores'],
            'privateMiB': statistics.mean(sum(p['PrivateBytes'] for p in s['processes']) / mib for s in samples),
            'workingSetMiB': statistics.mean(sum(p['WorkingSetBytes'] for p in s['processes']) / mib for s in samples),
            'allocatedMiBPerSecond': data['managedAllocatedBytes'] / mib / elapsed,
            'gc': data['collections'],
            'gpuDecode': statistics.mean(s['gpu'].get('VideoDecode', 0) for s in samples),
            'gpu3D': statistics.mean(s['gpu'].get('3D', 0) for s in samples),
            'gpuError': data['gpuError'],
            'fps': [v / elapsed for v in data['displayed']],
            'displayed': data['displayed'],
            'lost': data['lost'],
            'audioLost': data['audioLost'],
            'chatCounts': data['chatMessages'],
            'dockedRows': data['dockedRows'],
            'visibleDockedRows': data['visibleDockedRows'],
            'selectedForAudioCount': sum(data['audioSelected']),
            'processCountMinMax': [min(len(s['processes']) for s in samples), max(len(s['processes']) for s in samples)],
            'ioReadMiB': sum(p['ReadBytes'] - before.get(p['Pid'], {}).get('ReadBytes', 0) for p in data['afterProcesses']) / mib,
            'ioWriteMiB': sum(p['WriteBytes'] - before.get(p['Pid'], {}).get('WriteBytes', 0) for p in data['afterProcesses']) / mib,
            'channels': data['channels'],
            'qualities': data['qualities'],
            'dimensions': data['dimensions'],
            'testsSha256': data['testsSha256'],
            'applicationSha256': data['applicationSha256'],
            'infrastructureSha256': data['infrastructureSha256'],
            'cleanup': json.loads((path.parent / f"cycle-{data['cycle']}-cleanup.json").read_text()) if (path.parent / f"cycle-{data['cycle']}-cleanup.json").exists() else None,
        }
        rows.append(row)
aggregates = {}
for version in ('before', 'after'):
    subset = [r for r in rows if r['version'] == version]
    if not subset:
        continue
    aggregates[version] = {'trials': len(subset)}
    for metric in ('cpuCores', 'privateMiB', 'workingSetMiB', 'allocatedMiBPerSecond', 'gpuDecode', 'gpu3D', 'ioReadMiB', 'ioWriteMiB'):
        values = [r[metric] for r in subset]
        aggregates[version][metric] = {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
    aggregates[version]['lostPicturesTotal'] = sum(sum(r['lost']) for r in subset)
    aggregates[version]['displayedPicturesTotal'] = sum(sum(r['displayed']) for r in subset)
    aggregates[version]['lostAudioTotal'] = sum(sum(r['audioLost']) for r in subset)
out = {'trials': rows, 'aggregates': aggregates}
(root / 'formal-summary.json').write_text(json.dumps(out, indent=2) + '\n')
for r in rows:
    print(f"{r['trial']}: CPU {r['cpuCores']:.3f} cores, private {r['privateMiB']:.1f} MiB, WS {r['workingSetMiB']:.1f} MiB, allocation {r['allocatedMiBPerSecond']:.3f} MiB/s, GC {r['gc']}, fps " + ','.join(f'{v:.1f}' for v in r['fps']) + f", lost {r['lost']}, hidden rows {r['dockedRows']}, chat {r['chatCounts']}, cleanup {r['cleanup']}")
print(json.dumps(aggregates, indent=2))
