param([int]$Trials = 3, [int]$Seconds = 60)
$ErrorActionPreference = 'Stop'
for ($trial = 1; $trial -le $Trials; $trial++) {
    $order = if ($trial % 2) { @('before','after') } else { @('after','before') }
    foreach ($version in $order) {
        $label = "four-$trial-$version"
        $binary = if ($version -eq 'before') { 'baseline-bin' } else { 'updated-bin' }
        Write-Output "Starting $label at $([DateTime]::UtcNow.ToString('o'))"
        & (Join-Path $PSScriptRoot 'run-live.ps1') -Label $label -BinaryDirectory $binary -Seconds $Seconds -Warmup 20
        if ($LASTEXITCODE -ne 0) { throw "Live trial $label failed; inspect the complete raw output." }
    }
}
