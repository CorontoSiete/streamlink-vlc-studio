param(
    [string]$Label,
    [string]$BinaryDirectory = 'baseline-bin',
    [int]$Seconds = 45,
    [int]$Warmup = 20,
    [int]$Cycles = 1,
    [string]$Urls = 'https://www.twitch.tv/eslcs,https://www.twitch.tv/valorant,https://kick.com/cuffem,https://kick.com/deenthegreat'
)
$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/ComputerGuy/.dotnet'
$env:SVS_TEST_FILTER = 'multistream live smoke:'
$env:SVS_TEST_MULTISTREAM_LIVE_URLS = $Urls
$env:SVS_TEST_MULTISTREAM_LIVE_OUTPUT = Join-Path $PSScriptRoot $Label
if (Test-Path -LiteralPath $env:SVS_TEST_MULTISTREAM_LIVE_OUTPUT) { throw 'Use a fresh output label.' }
$env:SVS_TEST_MULTISTREAM_LIVE_SECONDS = [string]$Seconds
$env:SVS_TEST_MULTISTREAM_LIVE_WARMUP = [string]$Warmup
$env:SVS_TEST_MULTISTREAM_LIVE_CYCLES = [string]$Cycles
$env:SVS_TEST_TIMEOUT_SECONDS = '360'
$env:SVS_SKIP_INTERACTIVE_WINDOW_TESTS = 'false'
$env:SVS_EXPECTED_MAX_SKIPS = '0'
$env:SVS_BENCHMARK_VERSION = $Label
$binary = if ([IO.Path]::IsPathRooted($BinaryDirectory)) { $BinaryDirectory } else { Join-Path $PSScriptRoot $BinaryDirectory }
& "$env:DOTNET_ROOT/dotnet.exe" (Join-Path $binary 'StreamlinkVlcStudio.Tests.dll') *> (Join-Path $PSScriptRoot "$Label.log")
$result = $LASTEXITCODE
Get-Content -LiteralPath (Join-Path $PSScriptRoot "$Label.log") -Tail 12
exit $result
