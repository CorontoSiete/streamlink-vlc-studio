$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/ComputerGuy/.dotnet'
$env:SVS_TEST_FILTER = 'picture-in-picture resize keeps real GDI frames visible without white edges'
$env:SVS_SKIP_INTERACTIVE_WINDOW_TESTS = 'false'
$env:SVS_EXPECTED_MAX_SKIPS = '0'
$env:SVS_TEST_TIMEOUT_SECONDS = '120'
$env:SVS_TEST_VLC_DIRECTORY = 'C:/Program Files/VideoLAN/VLC'
$env:SVS_TEST_VLC_MEDIA = [IO.Path]::GetFullPath('.tmp/multistream-resources/blue.mp4')
$binaries = @{
    before = Join-Path $PSScriptRoot 'baseline-bin/StreamlinkVlcStudio.Tests.dll'
    after = [IO.Path]::GetFullPath('tests/StreamlinkVlcStudio.Tests/bin/Release/net10.0-windows10.0.19041.0/StreamlinkVlcStudio.Tests.dll')
}
$outcomes = @()
for ($trial = 1; $trial -le 3; $trial++) {
    $order = if ($trial % 2) { @('before','after') } else { @('after','before') }
    foreach ($version in $order) {
        $label = "pip-control-$trial-$version"
        $log = Join-Path $PSScriptRoot "verify-$label.log"
        if (Test-Path -LiteralPath $log) { throw 'Do not overwrite an earlier observation.' }
        $env:SVS_TEST_ARTIFACT_DIR = Join-Path $PSScriptRoot "ui-artifacts-$label"
        & "$env:DOTNET_ROOT/dotnet.exe" $binaries[$version] *> $log
        $outcomes += [pscustomobject]@{label=$label;exitCode=$LASTEXITCODE}
        Write-Output $label
        Get-Content -LiteralPath $log | Select-String '^PiP |^All |^FAIL|^SKIP|passed,'
    }
}
$outcomes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'pip-comparison.json') -Encoding UTF8
