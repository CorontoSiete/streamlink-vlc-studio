param([string]$Label, [string]$Filter)
$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/ComputerGuy/.dotnet'
$env:SVS_TEST_TIMEOUT_SECONDS = '120'
$env:SVS_TEST_MULTISTREAM_LIVE_URLS = $null
$env:SVS_RESOURCE_BENCHMARK = $null
$env:SVS_TEST_VLC_DIRECTORY = 'C:/Program Files/VideoLAN/VLC'
$env:SVS_TEST_VLC_MEDIA = [IO.Path]::GetFullPath('.tmp/multistream-resources/blue.mp4')
$env:SVS_TEST_ARTIFACT_DIR = Join-Path $PSScriptRoot ('ui-artifacts-' + $Label)
$env:SVS_TEST_FILTER = $Filter
$env:SVS_SKIP_INTERACTIVE_WINDOW_TESTS = 'false'
$env:SVS_EXPECTED_MAX_SKIPS = '0'
$log = Join-Path $PSScriptRoot ('verify-' + $Label + '.log')
if (Test-Path -LiteralPath $log) { throw 'Use a fresh label to preserve prior observations.' }
& "$env:DOTNET_ROOT/dotnet.exe" 'tests/StreamlinkVlcStudio.Tests/bin/Release/net10.0-windows10.0.19041.0/StreamlinkVlcStudio.Tests.dll' *> $log
$result = $LASTEXITCODE
Get-Content -LiteralPath $log -Tail 8
exit $result
